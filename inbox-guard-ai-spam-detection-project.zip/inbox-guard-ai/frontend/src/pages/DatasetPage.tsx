import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Search, WandSparkles } from "lucide-react";
import {
  Bar,
  BarChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "@/lib/recharts";
import { apiGet, apiPost } from "@/lib/api";
import { num, pct } from "@/lib/format";
import type { DatasetSamples, DatasetStats, PreprocessInspect } from "@/lib/types";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import StatCard from "@/components/StatCard";
import VerdictBadge from "@/components/VerdictBadge";

const PAGE_SIZE = 20;

type LabelFilter = "all" | "spam" | "ham";

const FILTERS: { value: LabelFilter; label: string; testId: string }[] = [
  { value: "all", label: "All", testId: "dataset-filter-all" },
  { value: "spam", label: "Spam", testId: "dataset-filter-spam" },
  { value: "ham", label: "Ham", testId: "dataset-filter-ham" },
];

export default function DatasetPage() {
  const [label, setLabel] = useState<LabelFilter>("all");
  const [search, setSearch] = useState("");
  const [offset, setOffset] = useState(0);
  const [playgroundText, setPlaygroundText] = useState(
    "WIN a FREE prize! Call http://x.co now",
  );
  const [inspect, setInspect] = useState<PreprocessInspect | null>(null);

  const statsQuery = useQuery({
    queryKey: ["dataset-stats"],
    queryFn: () => apiGet<DatasetStats>("/dataset/stats"),
  });
  const samplesQuery = useQuery({
    queryKey: ["dataset-samples", label, search, offset],
    queryFn: () =>
      apiGet<DatasetSamples>(
        `/dataset/samples?label=${label}&search=${encodeURIComponent(search)}&limit=${PAGE_SIZE}&offset=${offset}`,
      ),
  });

  const inspectMutation = useMutation({
    mutationFn: (text: string) => apiPost<PreprocessInspect>("/dataset/preprocess-inspect", { text }),
    onSuccess: (data) => setInspect(data),
  });

  const stats = statsQuery.data;
  const samples = samplesQuery.data;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-heading text-3xl font-bold tracking-tight">Dataset &amp; preprocessing</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Stage 1–2 of the workflow: explore the UCI SMS Spam Collection and watch every
          preprocessing step transform a raw message into model-ready tokens.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        <StatCard
          label="Messages"
          value={stats ? num(stats.total) : "—"}
          sub="labeled rows"
          testId="dataset-total-stat"
        />
        <StatCard
          label="Spam"
          value={stats ? num(stats.spam) : "—"}
          sub="fraud / ads / scams"
          accent="text-red-400"
          testId="dataset-spam-stat"
        />
        <StatCard
          label="Ham"
          value={stats ? num(stats.ham) : "—"}
          sub="regular messages"
          accent="text-emerald-400"
          testId="dataset-ham-stat"
        />
        <StatCard
          label="Spam ratio"
          value={stats ? pct(stats.spam_ratio) : "—"}
          sub="class imbalance"
          testId="dataset-ratio-stat"
        />
        <StatCard
          label="Avg words"
          value={stats ? stats.avg_words_total.toFixed(1) : "—"}
          sub={`spam ${stats?.avg_words_spam.toFixed(1) ?? "—"} · ham ${stats?.avg_words_ham.toFixed(1) ?? "—"}`}
          testId="dataset-words-stat"
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="font-heading text-base">Class distribution</CardTitle>
            <CardDescription>13.4% spam — a typical imbalanced text problem</CardDescription>
          </CardHeader>
          <CardContent>
            {stats ? (
              <div data-testid="dataset-class-distribution">
                <ResponsiveContainer width="100%" height={210}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: "Spam", value: stats.spam },
                        { name: "Ham", value: stats.ham },
                      ]}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={55}
                      outerRadius={85}
                      paddingAngle={3}
                      strokeWidth={0}
                    >
                      <Cell fill="#ef4444" />
                      <Cell fill="#10b981" />
                    </Pie>
                    <Tooltip formatter={(value: number) => `${num(value)} messages`} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex justify-center gap-6 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-red-500" /> Spam
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" /> Ham
                  </span>
                </div>
              </div>
            ) : (
              <div className="h-[210px] animate-pulse rounded-md bg-muted" />
            )}
          </CardContent>
        </Card>

        {[
          { title: "Top spam tokens", words: stats?.top_spam_words, fill: "#ef4444", testId: "dataset-top-spam-chart" },
          { title: "Top ham tokens", words: stats?.top_ham_words, fill: "#10b981", testId: "dataset-top-ham-chart" },
        ].map((chart) => (
          <Card
            key={chart.title}
            className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg"
          >
            <CardHeader>
              <CardTitle className="font-heading text-base">{chart.title}</CardTitle>
              <CardDescription>After cleaning + stopword removal</CardDescription>
            </CardHeader>
            <CardContent>
              {chart.words ? (
                <div data-testid={chart.testId}>
                  <ResponsiveContainer width="100%" height={240}>
                    <BarChart data={chart.words} layout="vertical" margin={{ left: 4, right: 16 }}>
                      <XAxis type="number" hide />
                      <YAxis
                        type="category"
                        dataKey="token"
                        width={104}
                        tickLine={false}
                        axisLine={false}
                        tick={{ fill: "#94a3b8", fontSize: 11 }}
                      />
                      <Tooltip
                        cursor={{ fill: "rgba(148,163,184,0.08)" }}
                        formatter={(value: number) => `${num(value)} occurrences`}
                      />
                      <Bar dataKey="count" fill={chart.fill} radius={[0, 4, 4, 0]} barSize={11} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-[240px] animate-pulse rounded-md bg-muted" />
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="lg:col-span-3 transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="font-heading text-base">Preprocessing playground</CardTitle>
            <CardDescription>
              Lowercase → URL / e-mail / number masking → punctuation strip → repeat collapse
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={playgroundText}
              onChange={(event) => setPlaygroundText(event.target.value)}
              rows={3}
              data-testid="preprocess-input"
            />
            <Button
              data-testid="preprocess-inspect-btn"
              disabled={!playgroundText.trim() || inspectMutation.isPending}
              onClick={() => inspectMutation.mutate(playgroundText)}
            >
              <WandSparkles className="h-4 w-4" />
              Run pipeline
            </Button>
            {inspect ? (
              <div className="space-y-3" data-testid="preprocess-result">
                {[
                  { label: "1 · Raw", value: inspect.raw },
                  { label: "2 · Lowercased", value: inspect.lowered },
                  { label: "3 · Normalized", value: inspect.normalized },
                ].map((stage) => (
                  <div key={stage.label}>
                    <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      {stage.label}
                    </p>
                    <p className="mt-1 rounded-md border border-border bg-slate-950/60 p-2.5 font-mono text-xs break-words text-sky-300">
                      {stage.value}
                    </p>
                  </div>
                ))}
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    4 · Tokens ({inspect.token_count})
                  </p>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {inspect.tokens.map((token, i) => (
                      <span
                        key={`${token}-${i}`}
                        className="rounded border border-emerald-500/30 bg-emerald-500/10 px-1.5 py-0.5 font-mono text-xs text-emerald-300"
                      >
                        {token}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ) : null}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2 transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="font-heading text-base">Message explorer</CardTitle>
            <CardDescription>
              {samples ? `${num(samples.total)} matching rows` : "Loading…"}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col gap-3">
              <div className="flex gap-2">
                {FILTERS.map((filter) => (
                  <Button
                    key={filter.value}
                    size="sm"
                    variant={label === filter.value ? "default" : "outline"}
                    data-testid={filter.testId}
                    onClick={() => {
                      setLabel(filter.value);
                      setOffset(0);
                    }}
                  >
                    {filter.label}
                  </Button>
                ))}
              </div>
              <div className="relative">
                <Search className="absolute top-2.5 left-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(event) => {
                    setSearch(event.target.value);
                    setOffset(0);
                  }}
                  placeholder="Search messages…"
                  className="pl-8"
                  data-testid="dataset-search-input"
                />
              </div>
            </div>

            <div className="space-y-2" data-testid="dataset-samples-table">
              {samples?.samples.map((sample) => (
                <div
                  key={sample.index}
                  className="flex items-start gap-3 rounded-lg border border-border p-2.5"
                >
                  <span className="w-10 shrink-0 pt-0.5 font-mono text-xs text-muted-foreground">
                    #{sample.index}
                  </span>
                  <VerdictBadge label={sample.label} className="shrink-0" />
                  <p className="text-sm break-words text-muted-foreground">{sample.text}</p>
                </div>
              ))}
              {samples && samples.samples.length === 0 ? (
                <p className="py-6 text-center text-sm text-muted-foreground">
                  No messages match this filter.
                </p>
              ) : null}
            </div>

            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground">
                {samples
                  ? `rows ${num(offset + 1)}–${num(offset + samples.samples.length)} of ${num(samples.total)}`
                  : ""}
              </p>
              <div className="flex gap-2">
                <Button
                  size="icon-sm"
                  variant="outline"
                  data-testid="dataset-samples-prev-btn"
                  disabled={offset === 0}
                  onClick={() => setOffset(Math.max(0, offset - PAGE_SIZE))}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  size="icon-sm"
                  variant="outline"
                  data-testid="dataset-samples-next-btn"
                  disabled={!samples || offset + PAGE_SIZE >= samples.total}
                  onClick={() => setOffset(offset + PAGE_SIZE)}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
