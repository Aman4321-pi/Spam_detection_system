import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CheckCircle2, CircleX, Download, FileDown, Send } from "lucide-react";
import { apiGet, apiPost } from "@/lib/api";
import { WORKFLOW_STEPS } from "@/lib/constants";
import { downloadProjectZip } from "@/lib/download";
import type { ProjectInfo, Submission } from "@/lib/types";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function SubmissionPage() {
  const queryClient = useQueryClient();
  const [studentName, setStudentName] = useState("");
  const [notes, setNotes] = useState("");

  const infoQuery = useQuery({
    queryKey: ["project-info"],
    queryFn: () => apiGet<ProjectInfo>("/project/info"),
  });
  const submissionsQuery = useQuery({
    queryKey: ["project-submissions"],
    queryFn: () => apiGet<Submission[]>("/project/submissions"),
  });

  const downloadMutation = useMutation({
    mutationFn: downloadProjectZip,
    onSuccess: () =>
      toast.success("Project ZIP generated", {
        description: "inbox-guard-ai-spam-detection-project.zip is downloading.",
      }),
    onError: () => toast.error("ZIP generation failed", { description: "Try again shortly." }),
  });

  const submitMutation = useMutation({
    mutationFn: () =>
      apiPost<Submission>("/project/submit", { student_name: studentName, notes }),
    onSuccess: () => {
      toast.success("Submission recorded", { description: "Good luck with your review!" });
      setStudentName("");
      setNotes("");
      queryClient.invalidateQueries({ queryKey: ["project-submissions"] });
    },
    onError: () => toast.error("Submission failed", { description: "Check the fields and retry." }),
  });

  const info = infoQuery.data;
  const submissions = submissionsQuery.data;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-heading text-3xl font-bold tracking-tight">Project submission</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Deliverables checklist, one-click export of the complete project, and your submission
          record.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="space-y-6">
          <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
            <CardHeader>
              <CardTitle className="font-heading text-base">Submission readiness</CardTitle>
              <CardDescription>Verified against the live project tree</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3" data-testid="submission-checklist-status">
                {info
                  ? info.deliverables.map((deliverable) => (
                      <div key={deliverable.name} className="flex items-start gap-3">
                        {deliverable.included ? (
                          <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-400" />
                        ) : (
                          <CircleX className="mt-0.5 h-5 w-5 shrink-0 text-red-400" />
                        )}
                        <div>
                          <p className="text-sm font-semibold">{deliverable.name}</p>
                          <p className="text-xs text-muted-foreground">{deliverable.detail}</p>
                        </div>
                      </div>
                    ))
                  : [...Array(6)].map((_, i) => (
                      <div key={i} className="h-10 animate-pulse rounded-md bg-muted" />
                    ))}
              </div>
            </CardContent>
          </Card>

          <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
            <CardHeader>
              <CardTitle className="font-heading text-base">Documented workflow</CardTitle>
              <CardDescription>
                README.md, WORKFLOW.md and TESTING.md ship inside the ZIP
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ol className="space-y-2.5">
                {WORKFLOW_STEPS.map((step) => (
                  <li key={step.step} className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-emerald-500/10 font-mono text-xs font-bold text-emerald-400 ring-1 ring-emerald-500/30">
                      {step.step}
                    </span>
                    <div>
                      <p className="text-sm font-semibold">{step.title}</p>
                      <p className="text-xs text-muted-foreground">{step.description}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-heading text-base">
                <FileDown className="h-4 w-4 text-emerald-400" />
                Download the project
              </CardTitle>
              <CardDescription>
                Backend + frontend + dataset + docs + tests, runnable locally
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button
                className="w-full"
                data-testid="download-zip-submit-btn"
                disabled={downloadMutation.isPending}
                onClick={() => downloadMutation.mutate()}
              >
                <Download className="h-4 w-4" />
                {downloadMutation.isPending
                  ? "Generating ZIP…"
                  : "Download Full Project ZIP"}
              </Button>
              <p className="text-center font-mono text-xs text-muted-foreground" data-testid="zip-meta">
                {info
                  ? `${info.file_count} files · ${info.zip_size_kb.toFixed(0)} KB · inbox-guard-ai/`
                  : "measuring bundle…"}
              </p>
              <pre
                className="overflow-x-auto rounded-md border border-border bg-slate-950/60 p-3 font-mono text-xs leading-relaxed text-sky-300"
                data-testid="run-commands-block"
              >
{`# backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn server:app --port 8001 --reload

# frontend (second terminal)
cd frontend && yarn && yarn dev`}
              </pre>
            </CardContent>
          </Card>

          <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
            <CardHeader>
              <CardTitle className="font-heading text-base">Submit your project</CardTitle>
              <CardDescription>Record your submission for the internship review</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Input
                value={studentName}
                onChange={(event) => setStudentName(event.target.value)}
                placeholder="Your name"
                data-testid="submission-name-input"
              />
              <Textarea
                value={notes}
                onChange={(event) => setNotes(event.target.value)}
                rows={3}
                placeholder="Notes for the reviewer (optional)"
                data-testid="submission-notes-input"
              />
              <Button
                className="w-full"
                data-testid="submission-form-submit-btn"
                disabled={!studentName.trim() || submitMutation.isPending}
                onClick={() => submitMutation.mutate()}
              >
                <Send className="h-4 w-4" />
                {submitMutation.isPending ? "Submitting…" : "Submit project"}
              </Button>

              {submissions && submissions.length > 0 ? (
                <div className="space-y-2" data-testid="submission-history-list">
                  {submissions.slice(0, 5).map((submission) => (
                    <div
                      key={submission.id}
                      className="flex items-center justify-between gap-3 rounded-lg border border-border p-2.5"
                    >
                      <div>
                        <p className="text-sm font-semibold">{submission.student_name}</p>
                        {submission.notes ? (
                          <p className="text-xs text-muted-foreground">{submission.notes}</p>
                        ) : null}
                      </div>
                      <span className="font-mono text-xs text-muted-foreground">
                        {new Date(submission.created_at).toLocaleString(undefined, {
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </span>
                    </div>
                  ))}
                </div>
              ) : null}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
