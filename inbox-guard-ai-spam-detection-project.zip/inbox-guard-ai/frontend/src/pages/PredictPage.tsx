import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Radar, ScanSearch } from "lucide-react";
import {
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "@/lib/recharts";
import { apiGet, apiPost } from "@/lib/api";
import { PRESET_MESSAGES } from "@/lib/constants";
import { pct } from "@/lib/format";
import type {
  BatchPredictResult,
  PredictResult,
  PredictionRecord,
} from "@/lib/types";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import VerdictBadge from "@/components/VerdictBadge";

export default function PredictPage() {
  const queryClient = useQueryClient();
  const [text, setText] = useState(PRESET_MESSAGES[0].text);
  const [batchText, setBatchText] = useState(
    `${PRESET_MESSAGES[0].text}\n${PRESET_MESSAGES[2].text}`,
  );
  const [result, setResult] = useState<PredictResult | null>(null);
  const [batchResults, setBatchResults] = useState<PredictResult[] | null>(null);

  const predictionsQuery = useQuery({
    queryKey: ["predictions"],
    queryFn: () => apiGet<PredictionRecord[]>("/model/predictions"),
  });

  const predictMutation = useMutation({
    mutationFn: (message: string) => apiPost<PredictResult>("/model/predict", { text: message }),
    onSuccess: (data) => {
      setResult(data);
      queryClient.invalidateQueries({ queryKey: ["predictions"] });
      toast.success(`Predicted ${data.label.toUpperCase()}`, {
        description: `Confidence ${pct(data.confidence)}`,
      });
    },
    onError: () =>
      toast.error("Prediction failed", {
        description: "No trained model is reachable — train one in Model Studio.",
      }),
  });

  const batchMutation = useMutation({
    mutationFn: (messages: string[]) =>
      apiPost<BatchPredictResult>("/model/predict-batch", { texts: messages }),
    onSuccess: (data) => {
      setBatchResults(data.results);
      queryClient.invalidateQueries({ queryKey: ["predictions"] });
      toast.success(`Scored ${data.results.length} messages`);
    },
    onError: () => toast.error("Batch prediction failed", { description: "Try again shortly." }),
  });

  const verdictColor = result?.label === "spam" ? "bg-red-500" : "bg-emerald-500";

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-heading text-3xl font-bold tracking-tight">Live Predict</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Stage 5: score new messages against the active model — single or in batch, with
          per-token explanations.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-heading text-base">
              <ScanSearch className="h-4 w-4 text-emerald-400" />
              Classifier
            </CardTitle>
            <CardDescription>Paste an SMS (or one per line for batch mode)</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="single">
              <TabsList>
                <TabsTrigger value="single">Single</TabsTrigger>
                <TabsTrigger value="batch">Batch</TabsTrigger>
              </TabsList>

              <TabsContent value="single" className="mt-4 space-y-4">
                <div className="flex flex-wrap gap-2">
                  {PRESET_MESSAGES.map((preset) => (
                    <Button
                      key={preset.id}
                      size="xs"
                      variant="outline"
                      data-testid={preset.id}
                      onClick={() => setText(preset.text)}
                    >
                      {preset.label}
                    </Button>
                  ))}
                </div>
                <Textarea
                  value={text}
                  onChange={(event) => setText(event.target.value)}
                  rows={4}
                  placeholder="Type or paste an SMS message…"
                  data-testid="predict-input-textarea"
                />
                <Button
                  data-testid="predict-submit-btn"
                  className="w-full"
                  disabled={!text.trim() || predictMutation.isPending}
                  onClick={() => predictMutation.mutate(text)}
                >
                  {predictMutation.isPending ? "Scoring…" : "Classify message"}
                </Button>

                {result ? (
                  <div
                    className="space-y-4 rounded-xl border border-border p-4 animate-in fade-in slide-in-from-bottom-2 duration-500"
                    data-testid="predict-result-card"
                  >
                    <div className="flex items-center justify-between gap-4">
                      <VerdictBadge label={result.label} testId="predict-verdict-badge" />
                      <p className="font-heading text-2xl font-bold" data-testid="predict-confidence-value">
                        {pct(result.confidence)}
                      </p>
                    </div>
                    <div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          data-testid="predict-confidence-bar"
                          className={`h-full ${verdictColor} transition-all duration-500`}
                          style={{ width: `${result.confidence * 100}%` }}
                        />
                      </div>
                      <div className="mt-2 flex justify-between font-mono text-xs text-muted-foreground">
                        <span>P(spam) {result.spam_probability.toFixed(3)}</span>
                        <span>P(ham) {result.ham_probability.toFixed(3)}</span>
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Model: {result.model_algorithm_label}
                    </p>
                  </div>
                ) : null}
              </TabsContent>

              <TabsContent value="batch" className="mt-4 space-y-4">
                <Textarea
                  value={batchText}
                  onChange={(event) => setBatchText(event.target.value)}
                  rows={5}
                  placeholder="One message per line…"
                  data-testid="predict-batch-input"
                />
                <Button
                  data-testid="predict-batch-submit-btn"
                  className="w-full"
                  disabled={!batchText.trim() || batchMutation.isPending}
                  onClick={() =>
                    batchMutation.mutate(
                      batchText
                        .split("\n")
                        .map((line) => line.trim())
                        .filter(Boolean)
                        .slice(0, 50),
                    )
                  }
                >
                  {batchMutation.isPending ? "Scoring…" : "Classify batch"}
                </Button>

                {batchResults ? (
                  <Table data-testid="predict-batch-table">
                    <TableHeader>
                      <TableRow>
                        <TableHead>Message</TableHead>
                        <TableHead>Verdict</TableHead>
                        <TableHead>Confidence</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {batchResults.map((row, i) => (
                        <TableRow key={`${row.text}-${i}`}>
                          <TableCell className="max-w-56 truncate text-sm">{row.text}</TableCell>
                          <TableCell>
                            <VerdictBadge label={row.label} />
                          </TableCell>
                          <TableCell className="font-mono text-xs">{pct(row.confidence)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : null}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-heading text-base">
                <Radar className="h-4 w-4 text-sky-400" />
                Why this verdict
              </CardTitle>
              <CardDescription>
                TF-IDF feature contributions — red pushes spam, green pushes ham
              </CardDescription>
            </CardHeader>
            <CardContent>
              {result && result.top_features.length > 0 ? (
                <div data-testid="predict-features-chart">
                  <ResponsiveContainer width="100%" height={Math.max(120, result.top_features.length * 26)}>
                    <BarChart
                      data={result.top_features}
                      layout="vertical"
                      margin={{ top: 0, right: 16, bottom: 0, left: 0 }}
                    >
                      <XAxis type="number" hide domain={["auto", "auto"]} />
                      <YAxis
                        type="category"
                        dataKey="feature"
                        width={132}
                        tickLine={false}
                        axisLine={false}
                        tick={{ fill: "#94a3b8", fontSize: 11 }}
                      />
                      <Tooltip formatter={(value: number) => `contribution ${value.toFixed(3)}`} />
                      <Bar dataKey="contribution" barSize={12} radius={[0, 4, 4, 0]}>
                        {result.top_features.map((feature, i) => (
                          <Cell
                            key={`${feature.feature}-${i}`}
                            fill={feature.contribution > 0 ? "#ef4444" : "#10b981"}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <p
                  className="py-10 text-center text-sm text-muted-foreground"
                  data-testid="predict-features-empty"
                >
                  Run a prediction to see which tokens moved the verdict.
                </p>
              )}
            </CardContent>
          </Card>

          <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
            <CardHeader>
              <CardTitle className="font-heading text-base">Recent predictions</CardTitle>
              <CardDescription>Every scored message is logged</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2" data-testid="predict-history-list">
                {predictionsQuery.data && predictionsQuery.data.length > 0 ? (
                  predictionsQuery.data.slice(0, 8).map((record) => (
                    <div
                      key={record.id}
                      className="flex items-center gap-3 rounded-lg border border-border p-2.5"
                    >
                      <VerdictBadge label={record.label} className="shrink-0" />
                      <p className="flex-1 truncate text-sm text-muted-foreground">{record.text}</p>
                      <span className="font-mono text-xs text-muted-foreground">
                        {pct(record.confidence)}
                      </span>
                    </div>
                  ))
                ) : (
                  <p className="py-4 text-center text-sm text-muted-foreground">
                    No predictions logged yet.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
