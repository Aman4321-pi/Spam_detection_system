import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowRight, Download, Send, ShieldCheck, Sparkles } from "lucide-react";
import { apiGet, apiPost } from "@/lib/api";
import { PRESET_MESSAGES, WORKFLOW_STEPS } from "@/lib/constants";
import { downloadProjectZip } from "@/lib/download";
import { pct } from "@/lib/format";
import type { DatasetStats, PredictResult, TrainingRun } from "@/lib/types";
import { Button, buttonVariants } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import VerdictBadge from "@/components/VerdictBadge";

export default function Home() {
  const statsQuery = useQuery({
    queryKey: ["dataset-stats"],
    queryFn: () => apiGet<DatasetStats>("/dataset/stats"),
  });
  const activeQuery = useQuery({
    queryKey: ["model-active"],
    queryFn: () => apiGet<TrainingRun>("/model/runs/active"),
    retry: false,
  });

  const [trialText, setTrialText] = useState(PRESET_MESSAGES[2].text);
  const [trialResult, setTrialResult] = useState<PredictResult | null>(null);

  const trialMutation = useMutation({
    mutationFn: (text: string) => apiPost<PredictResult>("/model/predict", { text }),
    onSuccess: (data) => {
      setTrialResult(data);
      toast.success(`Predicted ${data.label.toUpperCase()}`, {
        description: `Confidence ${pct(data.confidence)} · ${data.model_algorithm_label}`,
      });
    },
    onError: () =>
      toast.error("Prediction failed", {
        description: "No trained model is reachable — train one in Model Studio.",
      }),
  });

  const downloadMutation = useMutation({
    mutationFn: downloadProjectZip,
    onSuccess: () =>
      toast.success("Project ZIP generated", {
        description: "The full internship project is downloading.",
      }),
    onError: () => toast.error("ZIP generation failed", { description: "Try again shortly." }),
  });

  const stats = statsQuery.data;
  const run = activeQuery.data;

  return (
    <div className="space-y-8">
      <section className="grid gap-6 lg:grid-cols-12">
        <div className="space-y-6 lg:col-span-7">
          <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
            <span className="inline-flex items-center gap-2 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-emerald-400">
              <Sparkles className="h-3.5 w-3.5" />
              Virtual internship project · AI / ML
            </span>
            <h1 className="mt-4 font-heading text-4xl font-bold tracking-tight lg:text-5xl">
              Inbox Guard AI
              <span className="block text-emerald-400">Spam Detection System</span>
            </h1>
            <p className="mt-4 max-w-2xl text-base text-muted-foreground">
              An end-to-end machine-learning system that classifies SMS messages as spam or ham —
              from the raw UCI dataset through preprocessing, training and evaluation to a live
              prediction interface. Every stage is documented, tested and reproducible.
            </p>
          </div>

          <div className="space-y-2">
            {WORKFLOW_STEPS.map((step) => (
              <Link
                key={step.step}
                to={step.to}
                data-testid={`workflow-step-${step.step}`}
                className="group flex items-start gap-4 rounded-xl border border-border bg-card p-4 transition-colors duration-200 hover:border-slate-700 hover:shadow-lg"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400 ring-1 ring-emerald-500/30">
                  <step.icon className="h-5 w-5" />
                </span>
                <span className="flex-1">
                  <span className="font-heading text-sm font-bold">
                    {step.step}. {step.title}
                  </span>
                  <span className="mt-0.5 block text-sm text-muted-foreground">
                    {step.description}
                  </span>
                </span>
                <ArrowRight className="mt-2.5 h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200 group-hover:translate-x-1 group-hover:text-emerald-400" />
              </Link>
            ))}
          </div>

          <div className="flex flex-wrap gap-3">
            <Link
              to="/predict"
              className={buttonVariants() + " flex items-center gap-2"}
              data-testid="home-open-predict-btn"
            >
              <Send className="h-4 w-4" />
              Open Live Predict
            </Link>
            <Button
              variant="outline"
              data-testid="download-project-zip-hero-btn"
              disabled={downloadMutation.isPending}
              onClick={() => downloadMutation.mutate()}
            >
              <Download className="h-4 w-4" />
              {downloadMutation.isPending ? "Generating ZIP…" : "Download Project ZIP"}
            </Button>
          </div>
        </div>

        <div className="space-y-6 lg:col-span-5">
          <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
            <CardHeader>
              <CardTitle className="font-heading text-base">Dataset</CardTitle>
              <CardDescription>UCI SMS Spam Collection — labeled source data</CardDescription>
            </CardHeader>
            <CardContent>
              {stats ? (
                <div className="space-y-4" data-testid="home-dataset-card">
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div>
                      <p className="font-heading text-2xl font-bold" data-testid="home-dataset-total">
                        {stats.total.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">messages</p>
                    </div>
                    <div>
                      <p
                        className="font-heading text-2xl font-bold text-red-400"
                        data-testid="home-dataset-spam"
                      >
                        {stats.spam.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">spam</p>
                    </div>
                    <div>
                      <p
                        className="font-heading text-2xl font-bold text-emerald-400"
                        data-testid="home-dataset-ham"
                      >
                        {stats.ham.toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">ham</p>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>Ham {pct(stats.ham_ratio)}</span>
                      <span>Spam {pct(stats.spam_ratio)}</span>
                    </div>
                    <div className="mt-1.5 flex h-2 overflow-hidden rounded-full bg-muted">
                      <div className="bg-emerald-500" style={{ width: `${stats.ham_ratio * 100}%` }} />
                      <div className="bg-red-500" style={{ width: `${stats.spam_ratio * 100}%` }} />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-3" data-testid="home-dataset-loading">
                  <div className="h-8 animate-pulse rounded-md bg-muted" />
                  <div className="h-2 w-full animate-pulse rounded-full bg-muted" />
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 font-heading text-base">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                Active model
              </CardTitle>
              <CardDescription>Serving the Live Predict interface</CardDescription>
            </CardHeader>
            <CardContent>
              {run ? (
                <div className="space-y-3" data-testid="home-model-card">
                  <p className="font-heading text-lg font-bold" data-testid="home-model-algorithm">
                    {run.algorithm_label}
                  </p>
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div>
                      <p className="font-heading text-xl font-bold text-emerald-400" data-testid="home-model-accuracy">
                        {pct(run.metrics.accuracy)}
                      </p>
                      <p className="text-xs text-muted-foreground">accuracy</p>
                    </div>
                    <div>
                      <p className="font-heading text-xl font-bold text-sky-400">
                        {pct(run.metrics.f1)}
                      </p>
                      <p className="text-xs text-muted-foreground">F1 (spam)</p>
                    </div>
                    <div>
                      <p className="font-heading text-xl font-bold text-amber-400">
                        {pct(run.metrics.roc_auc)}
                      </p>
                      <p className="text-xs text-muted-foreground">ROC-AUC</p>
                    </div>
                  </div>
                  <Link to="/evaluate" className={buttonVariants({ variant: "link", size: "sm" })}>
                    View full evaluation →
                  </Link>
                </div>
              ) : activeQuery.isLoading ? (
                <div className="h-12 animate-pulse rounded-md bg-muted" data-testid="home-model-loading" />
              ) : (
                <div className="space-y-3" data-testid="home-model-empty">
                  <p className="text-sm text-muted-foreground">
                    No trained model yet — train one in Model Studio (takes a couple of seconds).
                  </p>
                  <Link to="/train" className={buttonVariants({ variant: "outline", size: "sm" })}>
                    Go to Model Studio
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
        <CardHeader>
          <CardTitle className="font-heading text-base">Quick trial</CardTitle>
          <CardDescription>
            Paste any SMS and the active model returns a spam/ham verdict with confidence.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {PRESET_MESSAGES.map((preset) => (
              <Button
                key={preset.id}
                size="xs"
                variant="outline"
                data-testid={preset.id}
                onClick={() => setTrialText(preset.text)}
              >
                {preset.label}
              </Button>
            ))}
          </div>
          <Textarea
            value={trialText}
            onChange={(event) => setTrialText(event.target.value)}
            placeholder="Type or paste an SMS message…"
            rows={3}
            data-testid="quick-predict-input"
          />
          <div className="flex flex-wrap items-center gap-4">
            <Button
              data-testid="quick-predict-btn"
              disabled={!trialText.trim() || trialMutation.isPending}
              onClick={() => trialMutation.mutate(trialText)}
            >
              {trialMutation.isPending ? "Scoring…" : "Predict"}
            </Button>
            {trialResult ? (
              <div
                className="flex flex-wrap items-center gap-3"
                data-testid="quick-predict-result"
              >
                <VerdictBadge label={trialResult.label} testId="quick-predict-verdict" />
                <span className="text-sm text-muted-foreground">
                  confidence{" "}
                  <span className="font-mono font-semibold text-foreground">
                    {pct(trialResult.confidence)}
                  </span>{" "}
                  · P(spam) {trialResult.spam_probability.toFixed(3)} · P(ham){" "}
                  {trialResult.ham_probability.toFixed(3)}
                </span>
              </div>
            ) : null}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
