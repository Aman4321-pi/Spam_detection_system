import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "@/lib/recharts";
import { apiGet } from "@/lib/api";
import { pct, pct2 } from "@/lib/format";
import type { TrainingRun } from "@/lib/types";
import { buttonVariants } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const AXIS_TICK = { fill: "#94a3b8", fontSize: 11 };

export default function EvaluationPage() {
  const activeQuery = useQuery({
    queryKey: ["model-active"],
    queryFn: () => apiGet<TrainingRun>("/model/runs/active"),
    retry: false,
  });

  const run = activeQuery.data;

  if (activeQuery.isLoading) {
    return (
      <div className="space-y-4" data-testid="eval-loading">
        <div className="h-9 w-72 animate-pulse rounded-md bg-muted" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="h-24 animate-pulse rounded-xl bg-muted" />
          ))}
        </div>
      </div>
    );
  }

  if (!run) {
    return (
      <Card className="mx-auto max-w-xl text-center" data-testid="eval-empty">
        <CardContent className="p-10">
          <p className="font-heading text-lg font-bold">No trained model yet</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Train a model first — evaluation needs a held-out test split and its metrics.
          </p>
          <Link to="/train" className={buttonVariants() + " mt-4 inline-flex"}>
            Open Model Studio
          </Link>
        </CardContent>
      </Card>
    );
  }

  const metrics = run.metrics;
  const rocData = metrics.roc_curve.map((point) => ({
    fpr: point.fpr,
    tpr: point.tpr,
    chance: point.fpr,
  }));
  const prData = metrics.pr_curve.map((point) => ({
    recall: point.recall,
    precision: point.precision,
  }));

  const metricCards = [
    { label: "Accuracy", value: metrics.accuracy, testId: "eval-accuracy-metric", accent: "text-emerald-400" },
    { label: "Precision (spam)", value: metrics.precision, testId: "eval-precision-metric", accent: "text-sky-400" },
    { label: "Recall (spam)", value: metrics.recall, testId: "eval-recall-metric", accent: "text-amber-400" },
    { label: "F1 (spam)", value: metrics.f1, testId: "eval-f1-metric", accent: "text-emerald-400" },
    { label: "ROC-AUC", value: metrics.roc_auc, testId: "eval-rocauc-metric", accent: "text-sky-400" },
  ];

  const confusionCells = [
    { key: "tn", value: metrics.confusion.tn, good: true, label: "TN · true ham" },
    { key: "fp", value: metrics.confusion.fp, good: false, label: "FP · false alarm" },
    { key: "fn", value: metrics.confusion.fn, good: false, label: "FN · missed spam" },
    { key: "tp", value: metrics.confusion.tp, good: true, label: "TP · caught spam" },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-heading text-3xl font-bold tracking-tight">Evaluation</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Stage 4: {run.algorithm_label} on {run.dataset.test.toLocaleString()} held-out messages
            ({Math.round(run.params.test_size * 100)}% split, stratified).
          </p>
        </div>
        <p className="font-mono text-xs text-muted-foreground" data-testid="eval-run-meta">
          run {run.id.slice(0, 8)} · trained in {Math.round(run.duration_ms)}ms
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        {metricCards.map((card) => (
          <Card
            key={card.label}
            size="sm"
            className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg"
          >
            <CardContent className="p-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                {card.label}
              </p>
              <p
                data-testid={card.testId}
                className={`mt-1 font-heading text-2xl font-bold tracking-tight ${card.accent}`}
              >
                {pct(card.value)}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="font-heading text-base">Confusion matrix</CardTitle>
            <CardDescription>Counts on the held-out split</CardDescription>
          </CardHeader>
          <CardContent>
            <div
              className="grid grid-cols-[92px_1fr_1fr] gap-2 text-center"
              data-testid="eval-confusion-matrix"
            >
              <div />
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Pred · ham
              </p>
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Pred · spam
              </p>
              <p className="flex items-center justify-end pr-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Act · ham
              </p>
              {confusionCells.slice(0, 2).map((cell) => (
                <div
                  key={cell.key}
                  title={cell.label}
                  className={`rounded-lg border p-4 ${
                    cell.good
                      ? "border-emerald-500/40 bg-emerald-500/10"
                      : "border-red-500/40 bg-red-500/10"
                  }`}
                  data-testid={`eval-cm-${cell.key}`}
                >
                  <p className="font-heading text-2xl font-bold">{cell.value.toLocaleString()}</p>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    {cell.label.split(" · ")[1]}
                  </p>
                </div>
              ))}
              <p className="flex items-center justify-end pr-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Act · spam
              </p>
              {confusionCells.slice(2).map((cell) => (
                <div
                  key={cell.key}
                  title={cell.label}
                  className={`rounded-lg border p-4 ${
                    cell.good
                      ? "border-emerald-500/40 bg-emerald-500/10"
                      : "border-red-500/40 bg-red-500/10"
                  }`}
                  data-testid={`eval-cm-${cell.key}`}
                >
                  <p className="font-heading text-2xl font-bold">{cell.value.toLocaleString()}</p>
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    {cell.label.split(" · ")[1]}
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="font-heading text-base">ROC curve</CardTitle>
            <CardDescription>AUC {pct2(metrics.roc_auc)} — true vs false positive rate</CardDescription>
          </CardHeader>
          <CardContent data-testid="eval-roc-chart">
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={rocData} margin={{ top: 4, right: 12, bottom: 4, left: -12 }}>
                <CartesianGrid stroke="#1f2937" strokeDasharray="3 3" />
                <XAxis
                  dataKey="fpr"
                  type="number"
                  domain={[0, 1]}
                  tick={AXIS_TICK}
                  tickFormatter={(value: number) => value.toFixed(1)}
                />
                <YAxis
                  type="number"
                  domain={[0, 1]}
                  tick={AXIS_TICK}
                  tickFormatter={(value: number) => value.toFixed(1)}
                />
                <Tooltip formatter={(value: number) => value.toFixed(3)} />
                <Line
                  type="monotone"
                  dataKey="tpr"
                  name="TPR"
                  stroke="#38bdf8"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="chance"
                  name="Chance"
                  stroke="#64748b"
                  strokeDasharray="4 4"
                  strokeWidth={1}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="font-heading text-base">Precision–recall curve</CardTitle>
            <CardDescription>The spam-class trade-off across thresholds</CardDescription>
          </CardHeader>
          <CardContent data-testid="eval-pr-chart">
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={prData} margin={{ top: 4, right: 12, bottom: 4, left: -12 }}>
                <CartesianGrid stroke="#1f2937" strokeDasharray="3 3" />
                <XAxis
                  dataKey="recall"
                  type="number"
                  domain={[0, 1]}
                  tick={AXIS_TICK}
                  tickFormatter={(value: number) => value.toFixed(1)}
                />
                <YAxis
                  type="number"
                  domain={[0, 1]}
                  tick={AXIS_TICK}
                  tickFormatter={(value: number) => value.toFixed(1)}
                />
                <Tooltip formatter={(value: number) => value.toFixed(3)} />
                <Line
                  type="monotone"
                  dataKey="precision"
                  name="Precision"
                  stroke="#10b981"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
        <CardHeader>
          <CardTitle className="font-heading text-base">Per-class metrics</CardTitle>
          <CardDescription>
            Dataset: {run.dataset.total.toLocaleString()} messages — {run.dataset.train.toLocaleString()}{" "}
            train / {run.dataset.test.toLocaleString()} test
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table data-testid="eval-per-class-table">
            <TableHeader>
              <TableRow>
                <TableHead>Class</TableHead>
                <TableHead>Precision</TableHead>
                <TableHead>Recall</TableHead>
                <TableHead>F1</TableHead>
                <TableHead>Support</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {metrics.per_class.map((row) => (
                <TableRow key={row.label}>
                  <TableCell className="font-heading text-sm font-bold capitalize">
                    {row.label}
                  </TableCell>
                  <TableCell className="font-mono text-xs">{pct2(row.precision)}</TableCell>
                  <TableCell className="font-mono text-xs">{pct2(row.recall)}</TableCell>
                  <TableCell className="font-mono text-xs">{pct2(row.f1)}</TableCell>
                  <TableCell className="font-mono text-xs">{row.support.toLocaleString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
