import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Loader2, Play } from "lucide-react";
import { apiGet, apiPost } from "@/lib/api";
import { ALGORITHM_LABELS, ALGORITHM_OPTIONS, MAX_FEATURES_OPTIONS, TEST_SIZE_OPTIONS } from "@/lib/constants";
import { pct } from "@/lib/format";
import type { Algorithm, TrainingRun } from "@/lib/types";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import VerdictBadge from "@/components/VerdictBadge";

const num2 = (value: number) => value.toLocaleString();

export default function TrainingPage() {
  const queryClient = useQueryClient();
  const [algorithm, setAlgorithm] = useState<Algorithm>("naive_bayes");
  const [testSize, setTestSize] = useState(0.2);
  const [maxFeatures, setMaxFeatures] = useState(5000);
  const [lastRun, setLastRun] = useState<TrainingRun | null>(null);

  const runsQuery = useQuery({
    queryKey: ["model-runs"],
    queryFn: () => apiGet<TrainingRun[]>("/model/runs"),
  });

  const trainMutation = useMutation({
    mutationFn: () =>
      apiPost<TrainingRun>("/model/train", {
        algorithm,
        test_size: testSize,
        max_features: maxFeatures,
      }),
    onSuccess: (run) => {
      setLastRun(run);
      queryClient.invalidateQueries({ queryKey: ["model-active"] });
      queryClient.invalidateQueries({ queryKey: ["model-runs"] });
      toast.success("Training complete", {
        description: `${run.algorithm_label} — accuracy ${pct(run.metrics.accuracy)} in ${Math.round(run.duration_ms)}ms`,
      });
    },
    onError: () => toast.error("Training failed", { description: "Check the backend and try again." }),
  });

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-heading text-3xl font-bold tracking-tight">Model Studio</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Stage 3 of the workflow: pick an algorithm and hyperparameters, train on the stratified
          split, and promote the result to the active model.
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        <div className="space-y-6 lg:col-span-2">
          <Card className="transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
            <CardHeader>
              <CardTitle className="font-heading text-base">Hyperparameters</CardTitle>
              <CardDescription>
                TF-IDF (1–2 grams, sublinear tf, English stopwords) feeds both classifiers.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Algorithm
                </label>
                <Select
                  value={algorithm}
                  onValueChange={(value: string) => setAlgorithm(value as Algorithm)}
                >
                  <SelectTrigger className="w-full" data-testid="train-algo-select">
                    <SelectValue>{(value: string) => ALGORITHM_LABELS[value as Algorithm]}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {ALGORITHM_OPTIONS.map((option) => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Test split
                </label>
                <Select value={String(testSize)} onValueChange={(value: string) => setTestSize(Number(value))}>
                  <SelectTrigger className="w-full" data-testid="train-testsize-select">
                    <SelectValue>{(value: string) => `${Math.round(Number(value) * 100)}% held out`}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {TEST_SIZE_OPTIONS.map((size) => (
                      <SelectItem key={size} value={String(size)}>
                        {Math.round(size * 100)}% held out
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Vocabulary size
                </label>
                <Select
                  value={String(maxFeatures)}
                  onValueChange={(value: string) => setMaxFeatures(Number(value))}
                >
                  <SelectTrigger className="w-full" data-testid="train-maxfeatures-select">
                    <SelectValue>{(value: string) => `${num2(Number(value))} max features`}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {MAX_FEATURES_OPTIONS.map((size) => (
                      <SelectItem key={size} value={String(size)}>
                        {num2(size)} max features
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Button
                className="w-full"
                data-testid="train-submit-btn"
                disabled={trainMutation.isPending}
                onClick={() => trainMutation.mutate()}
              >
                {trainMutation.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Play className="h-4 w-4" />
                )}
                {trainMutation.isPending ? "Training…" : "Train model"}
              </Button>

              <p
                className="rounded-md border border-border bg-slate-950/60 px-3 py-2 text-center font-mono text-xs text-sky-300"
                data-testid="train-status-indicator"
              >
                {trainMutation.isPending
                  ? "STATUS: fitting tf-idf + classifier…"
                  : lastRun
                    ? `STATUS: completed ${lastRun.algorithm_label} in ${Math.round(lastRun.duration_ms)}ms`
                    : "STATUS: idle — default Naive Bayes is serving"}
              </p>
            </CardContent>
          </Card>

          {lastRun ? (
            <Card
              className="animate-in fade-in slide-in-from-bottom-2 duration-500"
              data-testid="train-result-card"
            >
              <CardHeader>
                <CardTitle className="font-heading text-base">Latest run</CardTitle>
                <CardDescription>{lastRun.algorithm_label}</CardDescription>
              </CardHeader>
              <CardContent className="grid grid-cols-4 gap-3 text-center">
                {[
                  { label: "Accuracy", value: pct(lastRun.metrics.accuracy), testId: "train-result-accuracy" },
                  { label: "Precision", value: pct(lastRun.metrics.precision), testId: "train-result-precision" },
                  { label: "Recall", value: pct(lastRun.metrics.recall), testId: "train-result-recall" },
                  { label: "F1", value: pct(lastRun.metrics.f1), testId: "train-result-f1" },
                ].map((metric) => (
                  <div key={metric.label}>
                    <p
                      className="font-heading text-lg font-bold text-emerald-400"
                      data-testid={metric.testId}
                    >
                      {metric.value}
                    </p>
                    <p className="text-xs text-muted-foreground">{metric.label}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          ) : null}
        </div>

        <Card className="lg:col-span-3 transition-colors duration-200 hover:border-slate-700 hover:shadow-lg">
          <CardHeader>
            <CardTitle className="font-heading text-base">Training history</CardTitle>
            <CardDescription>
              Every run is stored with its full metric set — the newest becomes the active model.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {runsQuery.data && runsQuery.data.length > 0 ? (
              <Table data-testid="train-run-history-table">
                <TableHeader>
                  <TableRow>
                    <TableHead>Trained</TableHead>
                    <TableHead>Algorithm</TableHead>
                    <TableHead>Split</TableHead>
                    <TableHead>Accuracy</TableHead>
                    <TableHead>F1 (spam)</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {runsQuery.data.map((run) => (
                    <TableRow key={run.id}>
                      <TableCell className="font-mono text-xs">
                        {new Date(run.created_at).toLocaleString(undefined, {
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </TableCell>
                      <TableCell className="text-sm">{run.algorithm_label}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {run.dataset.train}/{run.dataset.test}
                      </TableCell>
                      <TableCell className="font-mono text-xs text-emerald-400">
                        {pct(run.metrics.accuracy)}
                      </TableCell>
                      <TableCell className="font-mono text-xs text-sky-400">
                        {pct(run.metrics.f1)}
                      </TableCell>
                      <TableCell>
                        {run.is_active ? (
                          <VerdictBadge label="ham" testId={`run-active-${run.id}`} className="text-[10px]" />
                        ) : (
                          <span className="text-xs text-muted-foreground">archived</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="space-y-2" data-testid="train-run-history-loading">
                <div className="h-10 animate-pulse rounded-md bg-muted" />
                <div className="h-10 animate-pulse rounded-md bg-muted" />
                <p className="pt-2 text-center text-sm text-muted-foreground">
                  No runs recorded yet — hit “Train model”.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
