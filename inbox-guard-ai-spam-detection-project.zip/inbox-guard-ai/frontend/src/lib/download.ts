import { apiGetBlob } from "@/lib/api";
import { ZIP_FILENAME } from "@/lib/constants";

/** Fetch the generated project bundle and hand it to the browser as a download. */
export async function downloadProjectZip(): Promise<void> {
  const blob = await apiGetBlob("/project/export-zip");
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = ZIP_FILENAME;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 2000);
}
