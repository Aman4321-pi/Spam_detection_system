import { Database, Gauge, ScanSearch, Send, SlidersHorizontal } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type { Algorithm } from "@/lib/types";

export const ALGORITHM_OPTIONS: { value: Algorithm; label: string }[] = [
  { value: "naive_bayes", label: "Multinomial Naive Bayes" },
  { value: "logistic_regression", label: "Logistic Regression" },
];

export const ALGORITHM_LABELS: Record<Algorithm, string> = {
  naive_bayes: "Multinomial Naive Bayes",
  logistic_regression: "Logistic Regression",
};

export const TEST_SIZE_OPTIONS = [0.1, 0.2, 0.3, 0.4];
export const MAX_FEATURES_OPTIONS = [1000, 3000, 5000, 10000];

export interface WorkflowStep {
  step: number;
  title: string;
  description: string;
  to: string;
  icon: LucideIcon;
}

export const WORKFLOW_STEPS: WorkflowStep[] = [
  {
    step: 1,
    title: "Data collection",
    description:
      "UCI SMS Spam Collection — 5,574 real, labeled messages (747 spam / 4,827 ham), shipped with the project.",
    to: "/dataset",
    icon: Database,
  },
  {
    step: 2,
    title: "Data preprocessing",
    description:
      "Lowercasing, URL / e-mail / number masking, punctuation stripping, stopword removal, then TF-IDF features.",
    to: "/dataset",
    icon: ScanSearch,
  },
  {
    step: 3,
    title: "Model training",
    description:
      "Stratified train/test split feeding Multinomial Naive Bayes or Logistic Regression — retrain from Model Studio.",
    to: "/train",
    icon: SlidersHorizontal,
  },
  {
    step: 4,
    title: "Evaluation",
    description:
      "Held-out accuracy, precision, recall, F1, ROC-AUC, confusion matrix and per-class breakdowns.",
    to: "/evaluate",
    icon: Gauge,
  },
  {
    step: 5,
    title: "Prediction interface",
    description:
      "Single & batch SMS scoring with confidence and per-token explanations of the verdict.",
    to: "/predict",
    icon: Send,
  },
];

export interface PresetMessage {
  id: string;
  label: string;
  text: string;
}

export const PRESET_MESSAGES: PresetMessage[] = [
  {
    id: "preset-msg-spam-1",
    label: "Lottery scam",
    text: "URGENT! You have won a £900 prize jackpot! Call 09061701939 now to claim your FREE prize.",
  },
  {
    id: "preset-msg-spam-2",
    label: "Phishing win",
    text: "Free entry to the gr8prizes weekly comp! Text WIN to 80085 to receive your prize.",
  },
  {
    id: "preset-msg-ham-1",
    label: "Casual plan",
    text: "Hey, are we still meeting for lunch tomorrow at the usual place?",
  },
  {
    id: "preset-msg-ham-2",
    label: "Everyday chat",
    text: "Can you send me the photos from today's class? Thanks, see you at school.",
  },
];

export const ZIP_FILENAME = "inbox-guard-ai-spam-detection-project.zip";
