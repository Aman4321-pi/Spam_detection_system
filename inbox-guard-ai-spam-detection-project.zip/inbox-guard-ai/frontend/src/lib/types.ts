// Hand-written mirrors of the Pydantic models in backend/models/ml.py — nothing
// infers across the HTTP boundary, so keep both sides in sync in the same edit.

export type Algorithm = "naive_bayes" | "logistic_regression";

export interface TokenCount {
  token: string;
  count: number;
}

export interface DatasetStats {
  total: number;
  spam: number;
  ham: number;
  spam_ratio: number;
  ham_ratio: number;
  avg_words_total: number;
  avg_words_spam: number;
  avg_words_ham: number;
  top_spam_words: TokenCount[];
  top_ham_words: TokenCount[];
}

export interface SampleMessage {
  index: number;
  label: string;
  text: string;
}

export interface DatasetSamples {
  total: number;
  samples: SampleMessage[];
}

export interface PreprocessInspect {
  raw: string;
  lowered: string;
  normalized: string;
  tokens: string[];
  token_count: number;
}

export interface ConfusionMatrix {
  tn: number;
  fp: number;
  fn: number;
  tp: number;
}

export interface PerClassMetric {
  label: string;
  precision: number;
  recall: number;
  f1: number;
  support: number;
}

export interface RocPoint {
  fpr: number;
  tpr: number;
}

export interface PrPoint {
  recall: number;
  precision: number;
}

export interface MetricsSummary {
  accuracy: number;
  precision: number;
  recall: number;
  f1: number;
  roc_auc: number;
  confusion: ConfusionMatrix;
  per_class: PerClassMetric[];
  roc_curve: RocPoint[];
  pr_curve: PrPoint[];
}

export interface DatasetSplit {
  total: number;
  train: number;
  test: number;
  spam: number;
  ham: number;
}

export interface TrainingRun {
  id: string;
  algorithm: string;
  algorithm_label: string;
  params: Record<string, number>;
  metrics: MetricsSummary;
  dataset: DatasetSplit;
  duration_ms: number;
  status: string;
  is_active: boolean;
  created_at: string;
}

export interface FeatureContribution {
  feature: string;
  weight: number;
  contribution: number;
  direction: string;
}

export interface PredictResult {
  text: string;
  label: string;
  confidence: number;
  spam_probability: number;
  ham_probability: number;
  top_features: FeatureContribution[];
  model_algorithm: string;
  model_algorithm_label: string;
}

export interface BatchPredictResult {
  results: PredictResult[];
}

export interface PredictionRecord {
  id: string;
  text: string;
  label: string;
  confidence: number;
  mode: string;
  created_at: string;
}

export interface Deliverable {
  name: string;
  included: boolean;
  detail: string;
}

export interface ProjectInfo {
  name: string;
  tagline: string;
  version: string;
  file_count: number;
  zip_size_kb: number;
  deliverables: Deliverable[];
  generated_at: string;
}

export interface Submission {
  id: string;
  student_name: string;
  notes: string;
  created_at: string;
}
