export const pct = (value: number) => `${(value * 100).toFixed(1)}%`;

export const pct2 = (value: number) => `${(value * 100).toFixed(2)}%`;

export const num = (value: number) => value.toLocaleString();
