import { Toaster } from "@/components/ui/sonner";
import { Route, Routes } from "react-router-dom";
import AppShell from "@/components/AppShell";
import DatasetPage from "@/pages/DatasetPage";
import EvaluationPage from "@/pages/EvaluationPage";
import Home from "@/pages/Home";
import PredictPage from "@/pages/PredictPage";
import SubmissionPage from "@/pages/SubmissionPage";
import TrainingPage from "@/pages/TrainingPage";

// One <Route> per page in src/pages; BrowserRouter already wraps this in main.tsx.
export default function App() {
  return (
    <>
      <Routes>
        <Route element={<AppShell />}>
          <Route path="/" element={<Home />} />
          <Route path="/dataset" element={<DatasetPage />} />
          <Route path="/train" element={<TrainingPage />} />
          <Route path="/evaluate" element={<EvaluationPage />} />
          <Route path="/predict" element={<PredictPage />} />
          <Route path="/submission" element={<SubmissionPage />} />
        </Route>
      </Routes>
      <Toaster />
    </>
  );
}
