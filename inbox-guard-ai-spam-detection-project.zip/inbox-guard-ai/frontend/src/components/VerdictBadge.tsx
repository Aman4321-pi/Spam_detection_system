import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface VerdictBadgeProps {
  label: string;
  testId?: string;
  className?: string;
}

export default function VerdictBadge({ label, testId, className }: VerdictBadgeProps) {
  const spam = label === "spam";
  return (
    <Badge
      data-testid={testId}
      className={cn(
        "border-transparent font-semibold tracking-wide text-white",
        spam ? "bg-red-500 hover:bg-red-500" : "bg-emerald-500 hover:bg-emerald-500",
        className,
      )}
    >
      {spam ? "SPAM" : "HAM"}
    </Badge>
  );
}
