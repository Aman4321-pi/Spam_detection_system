import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatCardProps {
  label: string;
  value: string | number;
  sub?: string;
  accent?: string;
  testId?: string;
  className?: string;
}

export default function StatCard({ label, value, sub, accent, testId, className }: StatCardProps) {
  return (
    <Card
      size="sm"
      className={cn(
        "transition-colors duration-200 hover:border-slate-700 hover:shadow-lg",
        "animate-in fade-in slide-in-from-bottom-2 duration-500",
        className,
      )}
    >
      <CardContent className="p-4">
        <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </p>
        <p
          data-testid={testId}
          className={cn("mt-1 font-heading text-2xl font-bold tracking-tight", accent)}
        >
          {value}
        </p>
        {sub ? <p className="mt-0.5 text-xs text-muted-foreground">{sub}</p> : null}
      </CardContent>
    </Card>
  );
}
