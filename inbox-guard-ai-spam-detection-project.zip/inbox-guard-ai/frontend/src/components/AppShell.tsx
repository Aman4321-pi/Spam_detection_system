import { useState } from "react";
import { Link, NavLink, Outlet } from "react-router-dom";
import { useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import {
  Database,
  Download,
  Gauge,
  PackageCheck,
  ScanSearch,
  Send,
  ShieldCheck,
  SlidersHorizontal,
} from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { downloadProjectZip } from "@/lib/download";

const NAV_LINKS = [
  { to: "/", label: "Overview", icon: ShieldCheck, testId: "nav-overview" },
  { to: "/dataset", label: "Dataset", icon: Database, testId: "nav-dataset" },
  { to: "/train", label: "Model Studio", icon: SlidersHorizontal, testId: "nav-train" },
  { to: "/evaluate", label: "Evaluation", icon: Gauge, testId: "nav-evaluate" },
  { to: "/predict", label: "Live Predict", icon: ScanSearch, testId: "nav-predict" },
  { to: "/submission", label: "Submission", icon: PackageCheck, testId: "nav-submission" },
];

export default function AppShell() {
  const [downloading, setDownloading] = useState(false);

  const downloadMutation = useMutation({
    mutationFn: downloadProjectZip,
    onMutate: () => setDownloading(true),
    onSettled: () => setDownloading(false),
    onSuccess: () =>
      toast.success("Project ZIP generated", {
        description: "inbox-guard-ai-spam-detection-project.zip is downloading.",
      }),
    onError: () =>
      toast.error("ZIP generation failed", {
        description: "The backend may be unreachable — try again shortly.",
      }),
  });

  return (
    <div className="min-h-svh bg-background">
      <header className="fixed inset-x-0 top-0 z-50 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-6">
          <Link to="/" className="flex items-center gap-2.5" data-testid="nav-brand">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/15 ring-1 ring-emerald-500/40">
              <ShieldCheck className="h-5 w-5 text-emerald-400" />
            </span>
            <span className="font-heading text-lg font-bold tracking-tight text-foreground">
              InboxGuard&nbsp;AI
            </span>
            <span className="ml-1 hidden items-center gap-1.5 rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-emerald-400 sm:flex">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-400" />
              Live
            </span>
          </Link>

          <nav className="hidden items-center gap-1 lg:flex">
            {NAV_LINKS.map(({ to, label, testId }) => (
              <NavLink
                key={to}
                to={to}
                end={to === "/"}
                data-testid={testId}
                className={({ isActive }: { isActive: boolean }) =>
                  `rounded-md px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                    isActive
                      ? "text-emerald-400"
                      : "text-slate-300 hover:text-sky-400"
                  }`
                }
              >
                {label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <Link
              to="/predict"
              data-testid="header-test-sms-btn"
              className={buttonVariants({ size: "sm" }) + " flex items-center gap-1.5"}
            >
              <Send className="h-3.5 w-3.5" />
              Test SMS
            </Link>
            <Button
              size="sm"
              variant="outline"
              data-testid="download-project-zip-btn"
              className="gap-1.5"
              disabled={downloading}
              onClick={() => downloadMutation.mutate()}
            >
              <Download className="h-3.5 w-3.5" />
              {downloading ? "Zipping…" : "ZIP"}
            </Button>
          </div>
        </div>
      </header>

      <main className="pt-16">
        <div className="mx-auto max-w-7xl p-6 lg:p-8">
          <Outlet />
        </div>
      </main>

      <footer className="border-t border-border py-6">
        <p className="text-center text-xs text-muted-foreground">
          Inbox Guard AI — Spam Detection System · Virtual internship project · Dataset: UCI SMS
          Spam Collection (Almeida &amp; Hidalgo, 2012)
        </p>
      </footer>
    </div>
  );
}
