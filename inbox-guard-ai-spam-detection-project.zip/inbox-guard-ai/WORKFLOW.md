# Documented workflow — Inbox Guard AI

End-to-end pipeline of the spam-detection system, stage by stage. Every stage maps to a page in
the dashboard and to code under `backend/ml/`.

## Stage 0 — Data collection

- Source: **UCI SMS Spam Collection**, 5,574 labeled messages (**747 spam / 4,827 ham**, 13.4% spam).
- Format: `label<TAB>message` lines in `backend/data/SMSSpamCollection.tsv`.
- Loader: `ml/dataset.py::load_dataset()` — returns parallel `(texts, labels)` lists; also serves
  dataset stats (class balance, average message lengths, top tokens per class after cleaning).

## Stage 1 — Data preprocessing (`ml/preprocess.py`)

Each raw SMS passes through the same normalisation pipeline:

1. **Lowercasing** — `WINNER!!` and `winner` become one signal.
2. **URL masking** — `http://…`, `www.…` → `urltoken` (URLs are a strong spam cue worth keeping).
3. **E-mail masking** — `someone@x.com` → `emailaddr`.
4. **HTML tag stripping**.
5. **Number masking** — digits → `numbertoken` (normalsises phone numbers, amounts, codes).
6. **Punctuation / non-alphabetic stripping** — kills `!!!`, `£`, emoji noise.
7. **Repeated-character collapse** — `freeeeee` → `freee`.
8. **Whitespace normalisation**.

Inspect any message through every stage with `POST /api/dataset/preprocess-inspect` or the
preprocessing playground on the **Dataset** page.

## Stage 2 — Feature engineering

- `TfidfVectorizer` over the cleaned text with:
  - `stop_words="english"` (removes high-information-zero function words),
  - `ngram_range=(1, 2)` (unigrams + bigrams — `free entry`, `call now`),
  - `sublinear_tf=True` (log-scaled term frequency dampens SMS-style repetition),
  - `max_features` configurable (1,000–20,000; default 5,000).

## Stage 3 — Model training (`ml/train.py`)

- **Stratified train/test split** (`train_test_split`, `stratify=y`, `random_state=42`) so both
  splits keep the 13.4% spam ratio. Default 80/20.
- Two classifiers, selectable in Model Studio:
  - **Multinomial Naive Bayes** (`alpha=1.0`) — the classic text baseline: `P(class) · ∏ P(token|class)`.
  - **Logistic Regression** (`C=1.0`, liblinear) — discriminative linear baseline over TF-IDF weights.
- Both live in one sklearn `Pipeline([tfidf, clf])`, so preprocessing + features + model are always
  fitted and persisted together (no train/serve skew).

## Stage 4 — Evaluation (held-out test split)

Reported for every run, stored in MongoDB and rendered on the **Evaluation** page:

- **Accuracy** — overall correctness.
- **Precision (spam)** — of messages flagged spam, how many were (`TP / (TP + FP)`).
- **Recall (spam)** — of real spam, how much was caught (`TP / (TP + FN)`).
- **F1 (spam)** — harmonic mean of the two.
- **ROC-AUC + ROC curve** — separation quality across all thresholds.
- **Precision–recall curve** — the informative pair under class imbalance.
- **Confusion matrix** — TN / FP / FN / TP counts.
- **Per-class breakdown** with support.

Typical results on this dataset: **accuracy ≈ 97–98%, spam F1 ≈ 0.92–0.95, ROC-AUC ≈ 0.99**.

## Stage 5 — Prediction interface (`ml/predict.py`)

- `POST /model/predict` — verdict (`spam`/`ham` at a 0.5 threshold), calibrated probabilities
  (`predict_proba`), and **explainability**: for each TF-IDF feature present in the message,
  `contribution = tf-idf weight × (weight_spam − weight_ham)`, where LR uses `coef_` and NB uses the
  log-probability gap `log P(t|spam) − log P(t|ham)`. Positive contributions push **spam** (red),
  negative push **ham** (green) — rendered as the "Why this verdict" chart.
- `POST /model/predict-batch` — up to 50 messages per call.
- Every scored message is logged (MongoDB `predictions`) and shown under "Recent predictions".

## Stage 6 — Persistence & serving

- The fitted pipeline is written atomically (`joblib` dump → `os.replace`) to
  `backend/ml_store/active_model.joblib` + `active_meta.json`.
- Run metadata (algorithm, params, full metrics, split, duration) goes to MongoDB
  `training_runs`; the newest run is the active one.
- On first boot with no artifact, `server.py` trains a default NB model in the background.

## Reproducibility

`random_state=42` fixes the split; the dataset is static; the whole pipeline is a single sklearn
`Pipeline` object — re-running training with the same parameters reproduces the same metrics.
