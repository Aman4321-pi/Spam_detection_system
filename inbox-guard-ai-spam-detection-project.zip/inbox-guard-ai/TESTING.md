# Testing guide — Inbox Guard AI

## Backend (pytest)

The suite hits the **live** uvicorn process (default `http://localhost:8001`), so it validates the
same app the browser sees.

```bash
cd backend
pytest                 # addopts already parallelise (pytest-xdist)
BACKEND_URL=http://localhost:8001 pytest   # explicit target if needed
```

Covered (`backend/tests/test_spam_api.py`):

| Test | Verifies |
|---|---|
| `test_dataset_stats` | dataset loads: 5,574 rows, spam+ham = total, ratios sane |
| `test_dataset_samples_filter` | label filter returns only spam rows |
| `test_dataset_samples_search` | substring search works |
| `test_preprocess_inspect_stages` | lowercase, URL masking, tokenisation stages |
| `test_preprocess_inspect_validation` | empty text → 422 (Pydantic) |
| `test_train_then_predict` | full round trip: train LR → accuracy > 0.9 → spam sample scored spam, ham sample scored ham |
| `test_predict_validation_422` | empty message → 422 |
| `test_predict_batch` | batch endpoint scores both classes |
| `test_runs_active_endpoint` | active-run + history endpoints |
| `test_run_not_found` | unknown run id → 404 |
| `test_project_export_zip` | ZIP: content-type, dataset + docs inside |
| `test_project_info` | deliverables checklist all green |
| `test_project_submission_roundtrip` | submission create + list |

## Frontend (Playwright)

`tests/` is a pre-scaffolded Playwright workspace; specs live in `tests/e2e/`.

```bash
cd tests && npx playwright test
```

## Manual QA matrix

| Flow | Expected |
|---|---|
| Overview `/` | dataset stats + active-model card render; quick trial returns verdict |
| Dataset `/dataset` | donut + token charts; filters/search paginate; playground shows 4 stages |
| Model Studio `/train` | train button runs, status flips to completed, history row appears as ACTIVE |
| Evaluation `/evaluate` | 5 metric cards, confusion matrix, ROC + PR curves, per-class table |
| Live Predict `/predict` | single verdict + confidence + feature chart; batch table; history log |
| Submission `/submission` | all checklist items green; ZIP downloads (~300 KB); submission records |
| Header "ZIP" button | downloads the same archive with a toast |

## API smoke (curl)

```bash
curl -s localhost:8001/api/dataset/stats | head -c 300
curl -s -X POST localhost:8001/api/model/predict \
  -H 'Content-Type: application/json' \
  -d '{"text": "URGENT! You have won a FREE prize. Call now!"}'
curl -sf -o project.zip localhost:8001/api/project/export-zip && unzip -l project.zip | head
```
