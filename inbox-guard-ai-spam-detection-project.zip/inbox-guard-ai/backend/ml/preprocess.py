"""Stage 1 of the workflow - text normalisation.

Pipeline of cleaning steps applied to every raw SMS before vectorisation:
lowercase -> URL/e-mail/HTML masking -> number masking -> punctuation
stripping -> repeated-character collapsing -> whitespace normalisation.
"""

import re

URL_RE = re.compile(r"(?:https?://\S+|www\.\S+)")
EMAIL_RE = re.compile(r"\S+@\S+")
HTML_RE = re.compile(r"<[^>]+>")
NUMBER_RE = re.compile(r"\d+(?:[.,]\d+)*")
NON_ALPHA_RE = re.compile(r"[^a-z\s]")
REPEAT_RE = re.compile(r"(.)\1{2,}")
SPACE_RE = re.compile(r"\s+")


def clean_text(text: str) -> str:
    """Normalise a raw SMS message into a clean lowercase token stream."""
    text = (text or "").lower()
    text = URL_RE.sub(" urltoken ", text)
    text = EMAIL_RE.sub(" emailaddr ", text)
    text = HTML_RE.sub(" ", text)
    text = NUMBER_RE.sub(" numbertoken ", text)
    text = NON_ALPHA_RE.sub(" ", text)
    text = REPEAT_RE.sub(r"\1\1", text)
    return SPACE_RE.sub(" ", text).strip()


def tokenize(text: str) -> list[str]:
    return clean_text(text).split()


def preprocess_stages(text: str) -> dict:
    """Every intermediate stage, for the preprocessing playground in the UI."""
    raw = text or ""
    normalized = clean_text(raw)
    tokens = normalized.split()
    return {
        "raw": raw,
        "lowered": raw.lower(),
        "normalized": normalized,
        "tokens": tokens,
        "token_count": len(tokens),
    }
