"""Active-model persistence: one fitted sklearn pipeline + its metadata on disk
at backend/ml_store/, written atomically so a failed dump never corrupts the
model the live app is serving."""

import json
import os
from pathlib import Path

import joblib

ARTIFACT_DIR = Path(__file__).resolve().parent.parent / "ml_store"
MODEL_PATH = ARTIFACT_DIR / "active_model.joblib"
META_PATH = ARTIFACT_DIR / "active_meta.json"


def save_active(pipeline, meta: dict) -> None:
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    tmp_model = MODEL_PATH.with_suffix(".tmp")
    joblib.dump(pipeline, tmp_model)
    os.replace(tmp_model, MODEL_PATH)

    tmp_meta = META_PATH.with_suffix(".tmp")
    tmp_meta.write_text(json.dumps(meta), encoding="utf-8")
    os.replace(tmp_meta, META_PATH)


def load_active() -> tuple[object | None, dict | None]:
    try:
        pipeline = joblib.load(MODEL_PATH)
        meta = json.loads(META_PATH.read_text(encoding="utf-8"))
        return pipeline, meta
    except Exception:
        return None, None
