"""Stages 2-3 of the workflow - model training and evaluation.

TF-IDF features (unigrams + bigrams) over the cleaned text, a stratified
train/test split, then Multinomial Naive Bayes or Logistic Regression. Every
run returns the full held-out metric set: accuracy, precision, recall, F1,
ROC-AUC, the confusion matrix, per-class breakdowns and ROC/PR curve points.
"""

import time
import uuid
from datetime import datetime, timezone

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline

from ml import store
from ml.dataset import load_dataset
from ml.preprocess import clean_text

ALGORITHM_LABELS = {
    "naive_bayes": "Multinomial Naive Bayes",
    "logistic_regression": "Logistic Regression",
}


def build_pipeline(algorithm: str, max_features: int) -> Pipeline:
    vectorizer = TfidfVectorizer(
        preprocessor=clean_text,
        lowercase=False,
        stop_words="english",
        ngram_range=(1, 2),
        max_features=max_features,
        sublinear_tf=True,
    )
    if algorithm == "naive_bayes":
        classifier = MultinomialNB(alpha=1.0)
    elif algorithm == "logistic_regression":
        classifier = LogisticRegression(C=1.0, solver="liblinear", max_iter=2000)
    else:
        raise ValueError(f"unknown algorithm: {algorithm}")
    return Pipeline([("tfidf", vectorizer), ("clf", classifier)])


def _downsample(points: list[dict], n: int = 60) -> list[dict]:
    if len(points) <= n:
        return points
    idx = np.linspace(0, len(points) - 1, n).astype(int)
    return [points[int(i)] for i in idx]


def train_run(
    algorithm: str = "naive_bayes",
    test_size: float = 0.2,
    max_features: int = 5000,
    random_state: int = 42,
) -> dict:
    texts, labels = load_dataset()
    y = np.array([1 if lab == "spam" else 0 for lab in labels])

    X_train, X_test, y_train, y_test = train_test_split(
        texts, y, test_size=test_size, random_state=random_state, stratify=y
    )

    started = time.perf_counter()
    pipeline = build_pipeline(algorithm, max_features)
    pipeline.fit(list(X_train), list(y_train))
    duration_ms = (time.perf_counter() - started) * 1000

    y_pred = pipeline.predict(list(X_test))
    y_prob = pipeline.predict_proba(list(X_test))[:, 1]

    tn, fp, fn, tp = (int(v) for v in confusion_matrix(y_test, y_pred).ravel())
    prec = precision_score(y_test, y_pred, labels=[0, 1], average=None, zero_division=0)
    rec = recall_score(y_test, y_pred, labels=[0, 1], average=None, zero_division=0)
    f1s = f1_score(y_test, y_pred, labels=[0, 1], average=None, zero_division=0)

    fpr, tpr, _ = roc_curve(y_test, y_prob)
    roc_points = [{"fpr": float(f), "tpr": float(t)} for f, t in zip(fpr, tpr)]
    prec_curve, rec_curve, _ = precision_recall_curve(y_test, y_prob)
    pr_points = [{"recall": float(r), "precision": float(p)} for r, p in zip(rec_curve, prec_curve)]

    metrics = {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision": float(precision_score(y_test, y_pred, zero_division=0)),
        "recall": float(recall_score(y_test, y_pred, zero_division=0)),
        "f1": float(f1_score(y_test, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, y_prob)),
        "confusion": {"tn": tn, "fp": fp, "fn": fn, "tp": tp},
        "per_class": [
            {
                "label": "ham",
                "precision": float(prec[0]),
                "recall": float(rec[0]),
                "f1": float(f1s[0]),
                "support": int(tn + fp),
            },
            {
                "label": "spam",
                "precision": float(prec[1]),
                "recall": float(rec[1]),
                "f1": float(f1s[1]),
                "support": int(fn + tp),
            },
        ],
        "roc_curve": _downsample(roc_points),
        "pr_curve": _downsample(pr_points),
    }

    run = {
        "id": str(uuid.uuid4()),
        "algorithm": algorithm,
        "algorithm_label": ALGORITHM_LABELS[algorithm],
        "params": {
            "test_size": float(test_size),
            "max_features": int(max_features),
            "random_state": int(random_state),
        },
        "metrics": metrics,
        "dataset": {
            "total": len(labels),
            "train": int(len(X_train)),
            "test": int(len(X_test)),
            "spam": int(y.sum()),
            "ham": int(len(y) - y.sum()),
        },
        "duration_ms": round(duration_ms, 1),
        "status": "completed",
        "is_active": True,
        "created_at": datetime.now(timezone.utc),
    }

    # The fitted pipeline is the artifact - persist it alongside the run metadata.
    store.save_active(
        pipeline,
        {
            "run_id": run["id"],
            "algorithm": algorithm,
            "algorithm_label": ALGORITHM_LABELS[algorithm],
            "trained_at": run["created_at"].isoformat(),
            "metrics": {"accuracy": metrics["accuracy"], "f1": metrics["f1"]},
        },
    )
    return run
