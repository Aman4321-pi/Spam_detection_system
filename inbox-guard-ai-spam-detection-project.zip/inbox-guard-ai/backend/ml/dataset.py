"""UCI SMS Spam Collection loader + aggregate statistics for the dataset pages.

The dataset ships as a tab-separated file (label<TAB>message per line) at
backend/data/SMSSpamCollection.tsv - 5,574 messages, 747 spam / 4,827 ham.
"""

from collections import Counter
from functools import lru_cache
from pathlib import Path

from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS

from ml.preprocess import tokenize

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "SMSSpamCollection.tsv"


def load_dataset() -> tuple[list[str], list[str]]:
    texts: list[str] = []
    labels: list[str] = []
    with DATA_PATH.open(encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or "\t" not in line:
                continue
            label, text = line.split("\t", 1)
            labels.append(label)
            texts.append(text)
    return texts, labels


def samples(label: str = "all", search: str = "", limit: int = 30, offset: int = 0) -> dict:
    """Paginated, filterable page of raw dataset rows for the explorer table."""
    texts, labels = load_dataset()
    needle = search.strip().lower()
    rows = [
        {"index": i, "label": lab, "text": txt}
        for i, (lab, txt) in enumerate(zip(labels, texts))
        if (label == "all" or lab == label) and (not needle or needle in txt.lower())
    ]
    return {"total": len(rows), "samples": rows[offset : offset + limit]}


@lru_cache(maxsize=1)
def _summary_cached() -> dict:
    texts, labels = load_dataset()
    total = len(labels)
    spam = sum(1 for lab in labels if lab == "spam")
    word_counts = [len(txt.split()) for txt in texts]
    spam_words = [n for n, lab in zip(word_counts, labels) if lab == "spam"]
    ham_words = [n for n, lab in zip(word_counts, labels) if lab == "ham"]

    spam_counter: Counter[str] = Counter()
    ham_counter: Counter[str] = Counter()
    for txt, lab in zip(texts, labels):
        tokens = [t for t in tokenize(txt) if t not in ENGLISH_STOP_WORDS and len(t) > 2]
        (spam_counter if lab == "spam" else ham_counter).update(tokens)

    return {
        "total": total,
        "spam": spam,
        "ham": total - spam,
        "spam_ratio": round(spam / total, 4) if total else 0.0,
        "ham_ratio": round((total - spam) / total, 4) if total else 0.0,
        "avg_words_total": round(sum(word_counts) / total, 2) if total else 0.0,
        "avg_words_spam": round(sum(spam_words) / len(spam_words), 2) if spam_words else 0.0,
        "avg_words_ham": round(sum(ham_words) / len(ham_words), 2) if ham_words else 0.0,
        "top_spam_words": [{"token": t, "count": c} for t, c in spam_counter.most_common(12)],
        "top_ham_words": [{"token": t, "count": c} for t, c in ham_counter.most_common(12)],
    }


def dataset_summary() -> dict:
    # The dataset is static, so the aggregate is computed once per process.
    return _summary_cached()
