"""Stage 4 of the workflow - inference with explainability.

Returns the spam/ham verdict, calibrated probabilities, and the TF-IDF features
present in the message that pushed it toward each class. For Logistic Regression
the weight is the fitted coefficient; for Naive Bayes it is the log-probability
gap log P(token|spam) - log P(token|ham). Both are positive for spam-leaning
features, so one code path explains either model.
"""

import numpy as np

from ml import store


class ModelNotTrained(Exception):
    pass


def _load():
    pipeline, meta = store.load_active()
    if pipeline is None:
        raise ModelNotTrained("no trained model available - run POST /api/model/train first")
    return pipeline, meta


def predict_message(text: str) -> dict:
    pipeline, meta = _load()
    vectorizer = pipeline.named_steps["tfidf"]
    classifier = pipeline.named_steps["clf"]

    proba = pipeline.predict_proba([text])[0]
    spam_index = int(np.where(classifier.classes_ == 1)[0][0])
    spam_probability = float(proba[spam_index])
    label = "spam" if spam_probability >= 0.5 else "ham"
    confidence = spam_probability if label == "spam" else 1.0 - spam_probability

    names = vectorizer.get_feature_names_out()
    if hasattr(classifier, "coef_"):
        weights = classifier.coef_[0]
    else:
        weights = classifier.feature_log_prob_[1] - classifier.feature_log_prob_[0]

    row = vectorizer.transform([text]).toarray()[0]
    contributions = []
    for i in row.nonzero()[0]:
        contribution = float(row[i] * weights[i])
        contributions.append(
            {
                "feature": str(names[i]),
                "weight": float(weights[i]),
                "contribution": contribution,
                "direction": "spam" if contribution > 0 else "ham",
            }
        )
    contributions.sort(key=lambda item: abs(item["contribution"]), reverse=True)

    return {
        "text": text,
        "label": label,
        "confidence": round(confidence, 4),
        "spam_probability": round(spam_probability, 4),
        "ham_probability": round(1.0 - spam_probability, 4),
        "top_features": contributions[:10],
        "model_algorithm": meta.get("algorithm", "unknown") if meta else "unknown",
        "model_algorithm_label": meta.get("algorithm_label", "unknown") if meta else "unknown",
    }
