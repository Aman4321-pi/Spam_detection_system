"""Pydantic v2 models shared by the spam-detection routers.

Every model here has a hand-written TS twin in frontend/src/lib/types.ts -
nothing infers across the HTTP boundary, so keep the two in sync in one edit.
"""

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field

Algorithm = Literal["naive_bayes", "logistic_regression"]


# --- dataset -----------------------------------------------------------------


class TokenCount(BaseModel):
    token: str
    count: int


class DatasetStats(BaseModel):
    total: int
    spam: int
    ham: int
    spam_ratio: float
    ham_ratio: float
    avg_words_total: float
    avg_words_spam: float
    avg_words_ham: float
    top_spam_words: list[TokenCount]
    top_ham_words: list[TokenCount]


class SampleMessage(BaseModel):
    index: int
    label: str
    text: str


class DatasetSamples(BaseModel):
    total: int
    samples: list[SampleMessage]


class PreprocessInspectRequest(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


class PreprocessInspect(BaseModel):
    raw: str
    lowered: str
    normalized: str
    tokens: list[str]
    token_count: int


# --- training / evaluation ---------------------------------------------------


class ConfusionMatrix(BaseModel):
    tn: int
    fp: int
    fn: int
    tp: int


class PerClassMetric(BaseModel):
    label: str
    precision: float
    recall: float
    f1: float
    support: int


class RocPoint(BaseModel):
    fpr: float
    tpr: float


class PrPoint(BaseModel):
    recall: float
    precision: float


class MetricsSummary(BaseModel):
    accuracy: float
    precision: float
    recall: float
    f1: float
    roc_auc: float
    confusion: ConfusionMatrix
    per_class: list[PerClassMetric]
    roc_curve: list[RocPoint]
    pr_curve: list[PrPoint]


class DatasetSplit(BaseModel):
    total: int
    train: int
    test: int
    spam: int
    ham: int


class TrainRequest(BaseModel):
    algorithm: Algorithm = "naive_bayes"
    test_size: float = Field(default=0.2, ge=0.1, le=0.5)
    max_features: int = Field(default=5000, ge=500, le=20000)


class TrainingRun(BaseModel):
    id: str
    algorithm: str
    algorithm_label: str
    params: dict[str, float | int]
    metrics: MetricsSummary
    dataset: DatasetSplit
    duration_ms: float
    status: str
    is_active: bool
    created_at: datetime


# --- prediction --------------------------------------------------------------


class PredictRequest(BaseModel):
    text: str = Field(min_length=1, max_length=4000)


class FeatureContribution(BaseModel):
    feature: str
    weight: float
    contribution: float
    direction: str


class PredictResult(BaseModel):
    text: str
    label: str
    confidence: float
    spam_probability: float
    ham_probability: float
    top_features: list[FeatureContribution]
    model_algorithm: str
    model_algorithm_label: str


class BatchPredictRequest(BaseModel):
    texts: list[str] = Field(min_length=1, max_length=50)


class BatchPredictResult(BaseModel):
    results: list[PredictResult]


class PredictionRecord(BaseModel):
    id: str
    text: str
    label: str
    confidence: float
    mode: str
    created_at: datetime


# --- project submission ------------------------------------------------------


class Deliverable(BaseModel):
    name: str
    included: bool
    detail: str


class ProjectInfo(BaseModel):
    name: str
    tagline: str
    version: str
    file_count: int
    zip_size_kb: float
    deliverables: list[Deliverable]
    generated_at: datetime


class SubmissionCreate(BaseModel):
    student_name: str = Field(min_length=1, max_length=80)
    notes: str = Field(default="", max_length=500)


class Submission(BaseModel):
    id: str
    student_name: str
    notes: str
    created_at: datetime
