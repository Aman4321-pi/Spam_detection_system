"""Idempotent seed: verify the dataset, ensure indexes, and train the default
model if no active run exists yet. Run from /app/backend: python seed.py."""

import asyncio

from lib.db import db, ensure_indexes
from ml.dataset import dataset_summary

SEED_ALGORITHM = "naive_bayes"


async def main() -> None:
    stats = dataset_summary()
    print(
        f"dataset: {stats['total']} messages "
        f"({stats['spam']} spam / {stats['ham']} ham)"
    )

    await ensure_indexes()

    from ml.train import train_run

    active = await db["training_runs"].find_one({"is_active": True})
    if active is None:
        run = train_run(SEED_ALGORITHM)
        await db["training_runs"].update_many({}, {"$set": {"is_active": False}})
        await db["training_runs"].insert_one(dict(run))
        print(
            f"seeded default model: {run['algorithm_label']} "
            f"accuracy={run['metrics']['accuracy']:.4f} f1={run['metrics']['f1']:.4f}"
        )
    else:
        print(
            f"active model already present: {active['algorithm_label']} (run {active['id']})"
        )


if __name__ == "__main__":
    asyncio.run(main())
