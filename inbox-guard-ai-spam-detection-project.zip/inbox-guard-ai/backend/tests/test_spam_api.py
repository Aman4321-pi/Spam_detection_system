"""API tests for the spam-detection system.

They hit the live uvicorn process (BACKEND_URL, default http://localhost:8001)
so the app under test is the same one the browser sees - see conftest.py.
"""

import io
import zipfile


def test_dataset_stats(client):
    res = client.get("/dataset/stats")
    assert res.status_code == 200
    body = res.json()
    assert body["total"] == 5574
    assert body["spam"] + body["ham"] == body["total"]
    assert 0 < body["spam_ratio"] < 1
    assert body["top_spam_words"][0]["count"] > 0


def test_dataset_samples_filter(client):
    res = client.get("/dataset/samples", params={"label": "spam", "limit": 5})
    assert res.status_code == 200
    body = res.json()
    assert body["total"] >= 5
    assert len(body["samples"]) == 5
    assert all(s["label"] == "spam" for s in body["samples"])


def test_dataset_samples_search(client):
    res = client.get("/dataset/samples", params={"search": "http", "limit": 10})
    assert res.status_code == 200
    body = res.json()
    assert body["total"] > 0
    assert all("http" in s["text"].lower() for s in body["samples"])


def test_preprocess_inspect_stages(client):
    res = client.post(
        "/dataset/preprocess-inspect",
        json={"text": "WIN a FREE prize! Call http://x.co now"},
    )
    assert res.status_code == 200
    body = res.json()
    assert body["tokens"][0] == "win"
    assert "urltoken" in body["tokens"]
    assert body["normalized"] == body["normalized"].lower()
    assert body["token_count"] == len(body["tokens"])


def test_preprocess_inspect_validation(client):
    res = client.post("/dataset/preprocess-inspect", json={"text": ""})
    assert res.status_code == 422


def test_train_then_predict(client):
    train = client.post(
        "/model/train",
        json={"algorithm": "logistic_regression", "test_size": 0.2, "max_features": 3000},
    )
    assert train.status_code == 200
    body = train.json()
    assert body["is_active"] is True
    assert body["algorithm"] == "logistic_regression"
    metrics = body["metrics"]
    assert metrics["accuracy"] > 0.9
    assert metrics["roc_auc"] > 0.9
    assert set(metrics["confusion"]) == {"tn", "fp", "fn", "tp"}
    assert len(metrics["roc_curve"]) > 10
    assert {c["label"] for c in metrics["per_class"]} == {"ham", "spam"}

    spam = client.post(
        "/model/predict",
        json={
            "text": "URGENT! You have won a 1 week FREE membership in our £100,000 "
            "prize jackpot! Text WIN to 80085 now!"
        },
    )
    assert spam.status_code == 200
    assert spam.json()["label"] == "spam"
    assert spam.json()["confidence"] > 0.5
    assert spam.json()["model_algorithm_label"] == "Logistic Regression"

    ham = client.post(
        "/model/predict",
        json={"text": "Hey, are we still meeting for lunch tomorrow at the usual place?"},
    )
    assert ham.status_code == 200
    assert ham.json()["label"] == "ham"


def test_predict_validation_422(client):
    res = client.post("/model/predict", json={"text": ""})
    assert res.status_code == 422


def test_predict_batch(client):
    res = client.post(
        "/model/predict-batch",
        json={
            "texts": [
                "URGENT! You have won a 1 week FREE membership in our £100,000 "
                "prize jackpot! Text WIN to 80085 now!",
                "Hey, are we still meeting for lunch tomorrow at the usual place?",
            ]
        },
    )
    assert res.status_code == 200
    results = res.json()["results"]
    assert len(results) == 2
    assert {r["label"] for r in results} == {"spam", "ham"}


def test_runs_active_endpoint(client):
    res = client.get("/model/runs/active")
    assert res.status_code == 200
    body = res.json()
    assert body["is_active"] is True
    assert body["duration_ms"] > 0

    listing = client.get("/model/runs")
    assert listing.status_code == 200
    assert any(r["id"] == body["id"] for r in listing.json())


def test_run_not_found(client):
    res = client.get("/model/runs/does-not-exist")
    assert res.status_code == 404


def test_project_export_zip(client):
    res = client.get("/project/export-zip")
    assert res.status_code == 200
    assert res.headers["content-type"].startswith("application/zip")
    assert "attachment" in res.headers["content-disposition"]
    bundle = zipfile.ZipFile(io.BytesIO(res.content))
    names = bundle.namelist()
    assert any(n.endswith("backend/server.py") for n in names)
    assert any(n.endswith("backend/data/SMSSpamCollection.tsv") for n in names)
    assert "inbox-guard-ai/README.md" in names
    assert "inbox-guard-ai/WORKFLOW.md" in names


def test_project_info(client):
    res = client.get("/project/info")
    assert res.status_code == 200
    body = res.json()
    assert body["file_count"] > 20
    assert body["zip_size_kb"] > 50
    assert all(d["included"] for d in body["deliverables"])


def test_project_submission_roundtrip(client):
    res = client.post(
        "/project/submit", json={"student_name": "Intern QA", "notes": "e2e check"}
    )
    assert res.status_code == 200
    body = res.json()
    assert body["id"]
    assert body["student_name"] == "Intern QA"

    listed = client.get("/project/submissions")
    assert listed.status_code == 200
    assert any(s["id"] == body["id"] for s in listed.json())
