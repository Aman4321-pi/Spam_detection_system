"""Builds the downloadable internship-project ZIP on the fly.

The bundle is the full, locally-runnable project: FastAPI backend, React
dashboard, the UCI dataset, the pytest suite, and the documented workflow
(README.md, WORKFLOW.md, TESTING.md) at the root of inbox-guard-ai/.
"""

import io
import zipfile
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # /app
BACKEND = ROOT / "backend"
FRONTEND = ROOT / "frontend"
TESTS = ROOT / "tests"
ASSETS = ROOT / "project_assets"

ZIP_FILENAME = "inbox-guard-ai-spam-detection-project.zip"
ARCHIVE_ROOT = "inbox-guard-ai"
EXCLUDED_PARTS = {
    "__pycache__",
    ".pytest_cache",
    "ml_store",
    "node_modules",
    "dist",
    ".emergent",
    ".git",
}

DIRS: list[tuple[Path, str]] = [
    (BACKEND / "ml", "backend/ml"),
    (BACKEND / "models", "backend/models"),
    (BACKEND / "routers", "backend/routers"),
    (BACKEND / "lib", "backend/lib"),
    (BACKEND / "tests", "backend/tests"),
    (BACKEND / "data", "backend/data"),
    (FRONTEND / "src", "frontend/src"),
    (FRONTEND / "public", "frontend/public"),
    (TESTS / "e2e", "tests/e2e"),
    (TESTS / "fixtures", "tests/fixtures"),
]

FILES: list[tuple[Path, str]] = [
    (BACKEND / "server.py", "backend/server.py"),
    (BACKEND / "requirements.txt", "backend/requirements.txt"),
    (BACKEND / "seed.py", "backend/seed.py"),
    (BACKEND / "pytest.ini", "backend/pytest.ini"),
    (BACKEND / ".env.example", "backend/.env.example"),
    (FRONTEND / "package.json", "frontend/package.json"),
    (FRONTEND / "yarn.lock", "frontend/yarn.lock"),
    (FRONTEND / "vite.config.ts", "frontend/vite.config.ts"),
    (FRONTEND / "tsconfig.json", "frontend/tsconfig.json"),
    (FRONTEND / "tsconfig.app.json", "frontend/tsconfig.app.json"),
    (FRONTEND / "tsconfig.node.json", "frontend/tsconfig.node.json"),
    (FRONTEND / "components.json", "frontend/components.json"),
    (FRONTEND / "index.html", "frontend/index.html"),
    (TESTS / "package.json", "tests/package.json"),
    (TESTS / "playwright.config.ts", "tests/playwright.config.ts"),
    (ASSETS / "README.md", "README.md"),
    (ASSETS / "WORKFLOW.md", "WORKFLOW.md"),
    (ASSETS / "TESTING.md", "TESTING.md"),
]


@dataclass
class ZipBundle:
    bytes: bytes
    file_count: int
    size_bytes: int
    deliverables: list[dict]


def _add_dir(zf: zipfile.ZipFile, src: Path, arc_dir: str, counter: list[int]) -> None:
    if not src.is_dir():
        return
    for path in sorted(src.rglob("*")):
        if path.is_dir() or EXCLUDED_PARTS.intersection(path.relative_to(src).parts):
            continue
        zf.write(path, f"{ARCHIVE_ROOT}/{arc_dir}/{path.relative_to(src)}")
        counter[0] += 1


def build_project_zip() -> ZipBundle:
    buffer = io.BytesIO()
    counter = [0]
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for src, arc_dir in DIRS:
            _add_dir(zf, src, arc_dir, counter)
        for src, arc in FILES:
            if src.is_file():
                zf.write(src, f"{ARCHIVE_ROOT}/{arc}")
                counter[0] += 1
    payload = buffer.getvalue()

    rows = 0
    dataset_file = BACKEND / "data" / "SMSSpamCollection.tsv"
    if dataset_file.exists():
        rows = sum(1 for line in dataset_file.read_text(encoding="utf-8").splitlines() if "\t" in line)

    deliverables = [
        {
            "name": "UCI SMS Spam Collection dataset",
            "included": rows > 5000,
            "detail": f"{rows} labeled messages at backend/data/SMSSpamCollection.tsv",
        },
        {
            "name": "ML pipeline (scikit-learn)",
            "included": (BACKEND / "ml" / "train.py").is_file(),
            "detail": "preprocessing, TF-IDF, MultinomialNB + LogisticRegression, held-out metrics",
        },
        {
            "name": "FastAPI backend",
            "included": (BACKEND / "server.py").is_file(),
            "detail": "dataset, training, evaluation, prediction and export endpoints under /api",
        },
        {
            "name": "React 19 dashboard",
            "included": (FRONTEND / "src" / "App.tsx").is_file(),
            "detail": "overview, dataset explorer, model studio, evaluation, live predict, submission",
        },
        {
            "name": "Backend test suite (pytest)",
            "included": any((BACKEND / "tests").glob("test_*.py")),
            "detail": "end-to-end API tests run against the live backend",
        },
        {
            "name": "Documented workflow + README",
            "included": (ASSETS / "WORKFLOW.md").is_file(),
            "detail": "README.md, WORKFLOW.md and TESTING.md at the archive root",
        },
    ]
    return ZipBundle(
        bytes=payload, file_count=counter[0], size_bytes=len(payload), deliverables=deliverables
    )
