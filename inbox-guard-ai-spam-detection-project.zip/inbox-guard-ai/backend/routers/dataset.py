"""Dataset + preprocessing endpoints - stage 1 of the workflow."""

from fastapi import APIRouter, Query

from ml.dataset import dataset_summary, samples
from ml.preprocess import preprocess_stages
from models.ml import (
    DatasetSamples,
    DatasetStats,
    PreprocessInspect,
    PreprocessInspectRequest,
)

router = APIRouter(prefix="/dataset", tags=["dataset"])


@router.get("/stats", response_model=DatasetStats)
async def get_dataset_stats():
    return dataset_summary()


@router.get("/samples", response_model=DatasetSamples)
async def get_dataset_samples(
    label: str = Query(default="all", pattern="^(all|spam|ham)$"),
    search: str = Query(default="", max_length=120),
    limit: int = Query(default=30, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    return samples(label=label, search=search, limit=limit, offset=offset)


@router.post("/preprocess-inspect", response_model=PreprocessInspect)
async def inspect_preprocessing(payload: PreprocessInspectRequest):
    return preprocess_stages(payload.text)
