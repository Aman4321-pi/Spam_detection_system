"""Project submission endpoints: deliverables scorecard, ZIP export, submissions."""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter
from fastapi.responses import Response

from lib.db import db
from lib.project_zip import ZIP_FILENAME, build_project_zip
from models.ml import ProjectInfo, Submission, SubmissionCreate

router = APIRouter(prefix="/project", tags=["project"])


def _aware(dt: datetime) -> datetime:
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


@router.get("/info", response_model=ProjectInfo)
async def project_info():
    bundle = build_project_zip()
    return ProjectInfo(
        name="Inbox Guard AI",
        tagline="Spam Detection System - virtual internship project",
        version="1.0.0",
        file_count=bundle.file_count,
        zip_size_kb=round(bundle.size_bytes / 1024, 1),
        deliverables=bundle.deliverables,
        generated_at=datetime.now(timezone.utc),
    )


@router.get("/export-zip")
async def export_zip():
    bundle = build_project_zip()
    return Response(
        content=bundle.bytes,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{ZIP_FILENAME}"'},
    )


@router.post("/submit", response_model=Submission)
async def create_submission(payload: SubmissionCreate):
    record = {
        "id": str(uuid.uuid4()),
        "student_name": payload.student_name,
        "notes": payload.notes,
        "created_at": datetime.now(timezone.utc),
    }
    await db["submissions"].insert_one(record)
    return record


@router.get("/submissions", response_model=list[Submission])
async def list_submissions():
    docs = await db["submissions"].find().sort("created_at", -1).to_list(10)
    out = []
    for doc in docs:
        doc = dict(doc)
        doc["created_at"] = _aware(doc["created_at"])
        out.append(Submission(**doc))
    return out
