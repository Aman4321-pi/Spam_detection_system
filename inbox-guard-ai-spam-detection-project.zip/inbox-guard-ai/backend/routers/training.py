"""Training + evaluation endpoints - stages 2-3 of the workflow."""

from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException

from lib.db import db
from ml.train import train_run
from models.ml import MetricsSummary, TrainRequest, TrainingRun

router = APIRouter(prefix="/model", tags=["model"])

RUNS = "training_runs"


def _aware(dt: datetime) -> datetime:
    """Motor hands naive UTC datetimes back - re-anchor before serialising."""
    return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt


def _run_from_doc(doc: dict) -> TrainingRun:
    doc = dict(doc)
    doc["created_at"] = _aware(doc["created_at"])
    return TrainingRun(**doc)


async def persist_run(run: dict) -> TrainingRun:
    """Store a finished run and make it the active model's run."""
    await db[RUNS].update_many({}, {"$set": {"is_active": False}})
    await db[RUNS].insert_one(dict(run))
    return _run_from_doc(run)


@router.post("/train", response_model=TrainingRun)
async def train_model(payload: TrainRequest):
    run = train_run(payload.algorithm, payload.test_size, payload.max_features)
    return await persist_run(run)


@router.get("/runs", response_model=list[TrainingRun])
async def list_runs():
    docs = await db[RUNS].find().sort("created_at", -1).to_list(25)
    return [_run_from_doc(d) for d in docs]


@router.get("/runs/active", response_model=TrainingRun)
async def active_run():
    doc = await db[RUNS].find_one({"is_active": True}, sort=[("created_at", -1)])
    if not doc:
        raise HTTPException(
            status_code=404, detail="no trained model yet - run POST /api/model/train first"
        )
    return _run_from_doc(doc)


@router.get("/metrics", response_model=MetricsSummary)
async def active_metrics():
    doc = await db[RUNS].find_one({"is_active": True}, sort=[("created_at", -1)])
    if not doc:
        raise HTTPException(
            status_code=404, detail="no trained model yet - run POST /api/model/train first"
        )
    return _run_from_doc(doc).metrics


@router.get("/runs/{run_id}", response_model=TrainingRun)
async def get_run(run_id: str):
    doc = await db[RUNS].find_one({"id": run_id})
    if not doc:
        raise HTTPException(status_code=404, detail="run not found")
    return _run_from_doc(doc)
