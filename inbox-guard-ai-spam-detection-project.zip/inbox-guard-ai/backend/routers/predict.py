"""Prediction interface endpoints - stage 4 of the workflow."""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException

from lib.db import db
from ml.predict import ModelNotTrained, predict_message
from models.ml import (
    BatchPredictRequest,
    BatchPredictResult,
    PredictRequest,
    PredictResult,
    PredictionRecord,
)

router = APIRouter(prefix="/model", tags=["predict"])

MAX_LOG_TEXT = 400


async def _log_prediction(result: dict, mode: str) -> None:
    record = {
        "id": str(uuid.uuid4()),
        "text": result["text"][:MAX_LOG_TEXT],
        "label": result["label"],
        "confidence": result["confidence"],
        "mode": mode,
        "created_at": datetime.now(timezone.utc),
    }
    await db["predictions"].insert_one(record)


@router.post("/predict", response_model=PredictResult)
async def predict(payload: PredictRequest):
    try:
        result = predict_message(payload.text)
    except ModelNotTrained as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    await _log_prediction(result, "single")
    return result


@router.post("/predict-batch", response_model=BatchPredictResult)
async def predict_batch(payload: BatchPredictRequest):
    try:
        results = [predict_message(text) for text in payload.texts]
    except ModelNotTrained as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    for result in results:
        await _log_prediction(result, "batch")
    return {"results": results}


@router.get("/predictions", response_model=list[PredictionRecord])
async def recent_predictions():
    docs = await db["predictions"].find().sort("created_at", -1).to_list(20)
    out = []
    for doc in docs:
        doc = dict(doc)
        dt = doc.get("created_at")
        if dt is not None and dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        doc["created_at"] = dt
        out.append(PredictionRecord(**doc))
    return out
