# Inbox Guard AI — Spam Detection System

A complete spam-detection system built as a practical virtual-internship project using AI &
machine-learning concepts: **data preprocessing → model training → evaluation → prediction
interface**, with a documented workflow, tests and a submission-ready export.

The live system is a web application: a **FastAPI + scikit-learn backend** (the ML pipeline,
dataset, metrics and model persistence) behind a **React 19 dashboard** (dataset explorer,
training studio, evaluation command center, live prediction terminal).

## Key features

| Feature | Where |
|---|---|
| Data preprocessing | `backend/ml/preprocess.py`, `/dataset` page, `POST /api/dataset/preprocess-inspect` |
| Model training | `backend/ml/train.py`, `/train` page, `POST /api/model/train` |
| Evaluation | `backend/ml/train.py` metrics block, `/evaluate` page, `GET /api/model/metrics` |
| Prediction interface | `backend/ml/predict.py`, `/predict` page, `POST /api/model/predict` (+ batch) |
| Documented workflow | `WORKFLOW.md` (this archive), step-by-step in the dashboard |
| Testing | `backend/tests/test_spam_api.py` (pytest, hits the live API), `tests/` (Playwright) |
| Project submission | `/submission` page — deliverables checklist + one-click ZIP export |

## Dataset

**UCI SMS Spam Collection** — 5,574 real, labeled SMS messages (747 spam / 4,827 ham),
shipped at `backend/data/SMSSpamCollection.tsv` as `label<TAB>message` per line.
Source: T. A. Almeida, J. M. G. Hidalgo et al., UCI Machine Learning Repository (2012).

## Project structure

```
inbox-guard-ai/
├── README.md, WORKFLOW.md, TESTING.md   <- documented workflow & testing guide
├── backend/                             FastAPI + motor (MongoDB) + scikit-learn
│   ├── server.py                        app bootstrap, /api router, startup auto-train
│   ├── ml/                              preprocess → dataset → train → predict → store
│   ├── models/ml.py                     Pydantic request/response models
│   ├── routers/                         dataset / training / predict / project endpoints
│   ├── lib/                             Mongo handle, dates, ZIP builder
│   ├── data/SMSSpamCollection.tsv       the UCI dataset
│   ├── tests/                           pytest suite (hits the live API)
│   └── seed.py                          idempotent seed: indexes + default model
├── frontend/                            Vite + React 19 + TypeScript + Tailwind + shadcn/ui
│   └── src/pages/                       Home, DatasetPage, TrainingPage, EvaluationPage,
│                                        PredictPage, SubmissionPage
└── tests/                               Playwright e2e workspace (pre-scaffolded)
```

## Quickstart

Requirements: Python 3.11+, Node 20+/yarn, a local MongoDB.

```bash
# backend
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env                 # MONGO_URL, DB_NAME, CORS_ORIGINS
uvicorn server:app --port 8001 --reload

# frontend (second terminal)
cd frontend
yarn
yarn dev                             # http://localhost:3000 (proxies /api -> :8001)
```

On first boot the backend trains a default Multinomial Naive Bayes model automatically, so the
prediction interface works immediately. Re/train anytime from **Model Studio** or
`POST /api/model/train`.

## API reference (all under `/api`)

| Method | Path | Purpose |
|---|---|---|
| GET | `/dataset/stats` | class balance, ratios, top tokens per class |
| GET | `/dataset/samples` | paginated, filterable, searchable dataset rows |
| POST | `/dataset/preprocess-inspect` | every preprocessing stage of a raw message |
| POST | `/model/train` | train (algorithm, test split, max features) → full metrics |
| GET | `/model/runs`, `/model/runs/active`, `/model/runs/{id}` | run history / active run |
| GET | `/model/metrics` | metrics of the active model |
| POST | `/model/predict` | single-message verdict + confidence + explanations |
| POST | `/model/predict-batch` | up to 50 messages per call |
| GET | `/model/predictions` | recent prediction log |
| GET | `/project/info`, `/project/export-zip` | deliverables scorecard / this ZIP |
| POST | `/project/submit`, GET `/project/submissions` | submission record |

## Testing

```bash
cd backend && pytest            # API tests against the live server on :8001
cd tests   && npx playwright test   # e2e (pre-scaffolded workspace)
```

See `TESTING.md` for the full test matrix and expected results.
